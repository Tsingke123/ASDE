function [RunResult,RunValue,RunTime,RunFES,RunOptimization,RunParameter]=EMFO(problem,N,runmax)

'EMFO'
D=Dim(problem);%3-6�е���˼�ο�CEP
lu=Boundary(problem,D);
TEV=Error();
FESMAX=300000;
RunOptimization=zeros(runmax,D);

for run=1:runmax
    TimeFlag=0;
    TempFES=FESMAX;
    t1=clock;
    x=Initpop(N,D,lu);%��Ⱥ��ʼ��
  
    fitness=benchmark_func(x,problem);%����ÿһ������ĺ���ֵ
   
    FES=N;%��ǰ�ĺ������۴������������Ѽ���Ĵ���
    k=1;
    Iteration=1;               %Current iteration
    Max_iteration=FESMAX/N ;    % Maximum numbef of iterations
    
    while FES<=FESMAX
        
        Flame_no=round(N-Iteration*((N-1)/Max_iteration));   %  Number of flames Eq. (3.14) in the paper
        fitness=benchmark_func(x,problem);%����ÿһ������ĺ���ֵ
        if Iteration==1
           % Sort the first population of moths
           [fitness_sorted, I]=sort(fitness);
           sorted_population=x(I,:); 
           globle_fitness = fitness_sorted(1);
            
        else                    
            % Sort the moths, choose 
            double_population=[previous_population;best_flames];
            double_fitness=[previous_fitness;best_flame_fitness];
        
            [double_fitness_sorted, I]=sort(double_fitness);
            double_sorted_population=double_population(I,:);
        
            fitness_sorted=double_fitness_sorted(1:N);
            sorted_population=double_sorted_population(1:N,:);        
        end
  %==================================�Ľ�===========================================  
            
    maxSuccess=2.5;       
    maxFailures=2.5;      
    adjustSuccess=0.8;
    adjustFailures=0.5;       
        
        %����Ӧ�������������
        if(mod(Iteration,10) == 0)
            if(fitness_sorted(1)==globle_fitness)
                maxSuccess = maxSuccess + maxSuccess*adjustSuccess;
                Flame_no = Flame_no + maxSuccess;
            else
                maxFailures = maxFailures-maxFailures*adjustFailures;
                Flame_no = Flame_no - maxFailures;
            end
            if(Flame_no >N)
                Flame_no = N;
            end
            if(Flame_no < 1)
                Flame_no = 1;
            end
        end       
        
        
%         Flame(Iteration)=Flame_no;
    
        % Update the flames
        best_flames=sorted_population;
        best_flame_fitness=fitness_sorted;
        
        previous_population=x;
        previous_fitness=fitness;
    
         % t linearly dicreases from -1 to -2 to calculate t in Eq. (3.12)
         a=-1+Iteration*((-1)/Max_iteration);
        
        %Main process of Flame's mutation    
%         rc=0.1;
        rc = rand;
        for i=1:N             
            
%             m=floor(rand*N)+1;
%             p=floor(rand*N)+1;
            randIdex = randperm(N,2);
            
            
            for j=1:D
                % D in Eq. (3.13)
                distance_to_flame=abs(sorted_population(i,j)-x(i,j));
                b=1;
                t=(a-1)*rand+1;       
                  
               if i<=Flame_no % Update the position of the moth with respect to its corresponsing flame                         
                  % Eq. (3.12)
                  if rand<rc
                      x(i,j)=distance_to_flame*exp(b.*t).*cos(t.*2*pi)+sorted_population(i,j);
                  else
                      x(i,j)=rand*(sorted_population(randIdex(1),j)-sorted_population(randIdex(2),j))+sorted_population(i,j);
                  end
               end
            
             if i>Flame_no                  
                 % Update the position of the moth with respct to one flame 
                  % Eq. (3.12)
                   if rand<rc
                       x(i,j)=distance_to_flame*exp(b.*t).*cos(t.*2*pi)+sorted_population(round(Flame_no),j);
                   else
                       x(i,j)=rand*(sorted_population(randIdex(1),j)-sorted_population(randIdex(2),j))+sorted_population(round(Flame_no),j);                      
                    end
            end
            
            end

            for j=1:D
                if  x(i,j)>lu(2,j)
                    x(i,j)=max(lu(1,j),2*lu(2,j)-x(i,j));%�����Ͻ紦��
                end
                if  x(i,j)<lu(1,j)
                    x(i,j)=min(lu(2,j),2*lu(1,j)-x(i,j));%�����½紦��
                end   
            end
        end
        
        for i=1:N 
            if FES==10000*0.1||mod(FES,10000)==0
                [kk,ll]=min(fitness);
                RunValue(run,k)=kk;
                Para(k,:)=x(ll,:);
                k=k+1;
                fprintf('Algorithm:%s problemIndex:%d Run:%d FES:%d Best:%g\n','EMFO',problem,run,FES,kk);
            end
            FES=FES+1;
            if TimeFlag==0
                if min(fitness)<=TEV
                    TempFES=FES;
                    TimeFlag=1;
                end
            end
        end
        
        Iteration=Iteration+1; 
        
    end
   % [kk,ll]=min(benchmark_func(x,problem));
    [kk,ll]=min(fitness);
    gbest=x(ll,:);
    t2=clock;
    RunTime(run)=etime(t2,t1);
    RunResult(run)=kk;
    RunFES(run)=TempFES;
    RunOptimization(run,1:D)=gbest;
    RunParameter=Para;
end
