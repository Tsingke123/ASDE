function [RunResult,RunValue,RunTime,RunFES,RunOptimization,RunParameter]=EMFO(problem,N,runmax)
%% An Improve Moth-flame optimization with multi-flames guidance
% written by ZhenYu Wang on 2021-10-30
'EMFO'
D=Dim(problem);%3-6�е���˼�ο�CEP
lu=Boundary(problem,D);
TEV=Error();
FESMAX=10000*D;
RunOptimization=zeros(runmax,D);

for run=1:runmax
    TimeFlag=0;
    TempFES=FESMAX;
    t1=clock;
    x=Initpop(N,D,lu);%��Ⱥ��ʼ��
    
    fitness=benchmark_func(x,problem);%����ÿһ������ĺ���ֵ  
    % Sort the first population of moths
    [fitness_sorted, I]=sort(fitness);
    sorted_population=x(I,:);
    % Update the flames
    best_flames=sorted_population;
    best_flame_fitness=fitness_sorted;
    globle_fitness = fitness_sorted(1);
    
    FES=N;%��ǰ�ĺ������۴������������Ѽ���Ĵ���
    k=1;
    Iteration=1;               %Current iteration
    Max_iteration=FESMAX/N ;    % Maximum numbef of iterations
    
    maxSuccess=2.5;       
    maxFailures=2.5;      
    adjustSuccess=0.8;
    adjustFailures=0.5; 
    Flame_no = N; % Initial number of flames
    while FES<FESMAX
        if(mod(Iteration,10) == 0)
            if(fitness_sorted(1)==globle_fitness)
                maxSuccess = maxSuccess + maxSuccess*adjustSuccess;
                Flame_no = Flame_no + maxSuccess;
            else
                maxFailures = maxFailures-maxFailures*adjustFailures;
                Flame_no = Flame_no - maxFailures;
            end
            if(Flame_no >N)
                Flame_no = N;
            end
            if(Flame_no < 1)
                Flame_no = 1;
            end
            globle_fitness = fitness_sorted(1);
        end
        
%         Flame_no=round(N-Iteration*((N-1)/Max_iteration));   %  Number of flames Eq. (3.14) in the paper
        
         % a linearly dicreases from -1 to -2 to calculate t in Eq. (3.12)
         a=-1+Iteration*((-1)/Max_iteration);
        
        %Main process of Flame's mutation 
        rc = rand;
        for i=1:N
            randIdex = randperm(N,2); 
            for j=1:D
                b=1;
              t=(a-1)*rand+1; 
               if i<=Flame_no
                  if rand < rc
                      distance_to_flame=abs(sorted_population(i,j)-x(i,j));             
                      x(i,j)=distance_to_flame*exp(b.*t).*cos(t.*2*pi)+sorted_population(i,j);
                  else
                      x(i,j)=rand*(sorted_population(randIdex(1),j)-sorted_population(randIdex(2),j))+sorted_population(i,j);
                  end
               end
            
               if i>Flame_no
                   if rand < rc
                       distance_to_flame=abs(sorted_population(round(Flame_no),j)-x(i,j));               
                       x(i,j)=distance_to_flame*exp(b.*t).*cos(t.*2*pi)+sorted_population(round(Flame_no),j);
                   else
                       x(i,j)=rand*(sorted_population(randIdex(1),j)-sorted_population(randIdex(2),j))+sorted_population(round(Flame_no),j);
                   end
                  
               end
            
            end
        end
        x = boundConstraint(x,lu);
        fitness = benchmark_func(x,problem);%����ÿһ������ĺ���ֵ
         % Sort the moths, choose
        double_population=[x;best_flames];
        double_fitness=[fitness;best_flame_fitness];
        [double_fitness_sorted, I]=sort(double_fitness);
        double_sorted_population=double_population(I,:);
        fitness_sorted=double_fitness_sorted(1:N);
        sorted_population=double_sorted_population(1:N,:);
        % Update the flames
        best_flames=sorted_population;
        best_flame_fitness=fitness_sorted;
        
        for i=1:N 
            if FES==10000*0.1||mod(FES,10000)==0
%                 [kk,ll]=min(fitness);
                RunValue(run,k)=best_flame_fitness(1,1);
                Para(k,:)=best_flames(1,:);
                k=k+1;
                fprintf('Algorithm:%s problemIndex:%d Run:%d FES:%d Best:%g\n','EMFO',problem,run,FES,best_flame_fitness(1,1)); 
            end
            FES=FES+1;
            if TimeFlag==0
                if best_flame_fitness<=TEV %��С�ڵ��ڸ�������ֵʱ���������۵Ĵ���%
                    TempFES=FES;
                    TimeFlag=1;
                end
            end
        end
        Iteration=Iteration+1;
    end
    t2=clock;
    RunTime(run)=etime(t2,t1);
    RunResult(run)=best_flame_fitness(1,1);
    RunFES(run)=TempFES;
    RunOptimization(run,1:D)=best_flames(1,:);
    RunParameter=Para;  
end
