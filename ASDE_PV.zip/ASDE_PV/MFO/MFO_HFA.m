function [RunResult,RunValue,RunTime,RunFES,RunOptimization,RunParameter]=MFO_HFA(problem,N,runmax)
%Moth-flame optimization with historical flame archive
% written by ZhenYu Wang on 2021-06-06
    'MFO_HFA'
    D=Dim(problem);%3-6�е���˼�ο�CEP
    lu=Boundary(problem,D);
    TEV=Error();
    FESMAX=10000*D;
    RunOptimization=zeros(runmax,D);
    
    init_rate = 0.1;
    
    for run=1:runmax
        TimeFlag=0;
        TempFES=FESMAX;
        t1=clock;
        x=Initpop(N,D,lu);%��Ⱥ��ʼ��
        fitness=benchmark_func(x,problem);
        archive.x = x;
        archive.fitness = fitness;
        FES=N;%��ǰ�ĺ������۴������������Ѽ���Ĵ���
        k=1;
        Iteration=1;               %Current iteration
        Max_iteration=FESMAX/N ;    % Maximum numbef of iterations
        
        while FES<=FESMAX
            Flame_no=round((N-Iteration*(N/Max_iteration))*init_rate);   %  Number of flames Eq. (3.14) in the paper
            Flame_no = max(Flame_no,1);
            % a linearly dicreases from -1 to -2 to calculate t in Eq. (3.12)
            a=-1+Iteration*((-1)/Max_iteration);
            
            %Main process of Flame's mutation   
            [~,I] = sort(archive.fitness);
            sorted_pop = archive.x(I,:);
            for i=1:N
                b=1;
                t=(a-1)*rand(1,D)+1;
                pbest = ceil(rand*Flame_no);
                distance = sorted_pop(pbest,:) - x(i,:);
                x(i,:) = distance.*exp(b.*t).*cos(t.*2*pi)+ sorted_pop(pbest,:);
                for j=1:D
                    if  x(i,j)>lu(2,j)
                        x(i,j)=max(lu(1,j),2*lu(2,j)-x(i,j));%�����Ͻ紦��
                    end
                    if  x(i,j)<lu(1,j)
                        x(i,j)=min(lu(2,j),2*lu(1,j)-x(i,j));%�����½紦��
                    end   
                end
            end
            fitness = benchmark_func(x,problem);
            mask = (fitness < archive.fitness);
            archive.x(mask,:) = x(mask,:);
            archive.fitness(mask,1) = fitness(mask,1);

            for i=1:N 
                if FES==10000*0.1||mod(FES,10000)==0
                    [kk,ll]=min(archive.fitness);
                    RunValue(run,k)=kk;
                    Para(k,:)=archive.x(ll,:);
                    k=k+1;
                    
                    fprintf('Algorithm:%s problemIndex:%d Run:%d FES:%d Best:%g\n','MFO_HFA',problem,run,FES,kk);
                end
                FES=FES+1;
                if TimeFlag==0
                    if min(archive.fitness)<=TEV %��С�ڵ��ڸ�������ֵʱ���������۵Ĵ���%
                        TempFES=FES;
                        TimeFlag=1;
                    end
                end
            end

            Iteration=Iteration+1; 

        end
       % [kk,ll]=min(benchmark_func(x,problem));
        [kk,ll]=min(archive.fitness);
        gbest=archive.x(ll,:);
        t2=clock;
        RunTime(run)=etime(t2,t1);
        RunResult(run)=kk;
        RunFES(run)=TempFES;
        RunOptimization(run,1:D)=gbest;
        RunParameter=Para;
    end

end

