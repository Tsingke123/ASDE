function [RunResult,RunValue,RunTime,RunFES,RunOptimization,RunParameter]=CLPSO(problem,N,runmax)

     'CLPSO'
    D=Dim(problem);%3-6�е���˼�ο�CEP
    lu=Boundary(problem,D);
    TEV=Error(D);
    FESMAX=300000;
    RunOptimization=zeros(runmax,D);
    me= round(FESMAX / N);
    ps=N;
    % D=Dimension;
    cc=[1 1];   %acceleration constants
    t=0:1/(ps-1):1;t=5.*t;
    Pc=0.0+(0.5-0.0).*(exp(t)-exp(t(1)))./(exp(t(ps))-exp(t(1)));
    m=0.*ones(ps,1);
    iwt=0.9-(1:me)*(0.7/me);
    cc=[1.49445 1.49445]; 
    mv=0.2*(lu(2,:)-lu(1,:));
    VRmin=repmat(lu(1,:),ps,1);
    VRmax=repmat(lu(2,:),ps,1);
    Vmin=repmat(-mv,ps,1);
    Vmax=-Vmin;
    for run=1:runmax
        TimeFlag=0;
        TempFES=FESMAX;
        t1=clock;
        count=1;
        pos=VRmin+(VRmax-VRmin).*rand(ps,D);

        for i=1:ps
            e(i,1)=benchmark_func(pos(i,:), problem);
        end

        fitcount=ps;
        vel=Vmin+2.*Vmax.*rand(ps,D);%initialize the velocity of the particles
        pbest=pos;
        pbestval=e; %initialize the pbest and the pbest's fitness value
        [gbestval,gbestid]=min(pbestval);
        gbest=pbest(gbestid,:);%initialize the gbest and the gbest's fitness value
        gbestrep=repmat(gbest,ps,1);

        stay_num=zeros(ps,1); 

        ai=zeros(ps,D);
        f_pbest=1:ps;f_pbest=repmat(f_pbest',1,D);
        for k=1:ps       
            ar=randperm(D);
            ai(k,ar(1:m(k)))=1;
            fi1=ceil(ps*rand(1,D));
            fi2=ceil(ps*rand(1,D));
            fi=(pbestval(fi1)<pbestval(fi2))'.*fi1+(pbestval(fi1)>=pbestval(fi2))'.*fi2;
            bi=ceil(rand(1,D)-1+Pc(k));
            if bi==zeros(1,D),rc=randperm(D);bi(rc(1))=1;end
            f_pbest(k,:)=bi.*fi+(1-bi).*f_pbest(k,:);
        end

        stop_num=0;
        i=1;
         while i<=me && fitcount<= FESMAX
            i=i+1;
            for k=1:ps
              if stay_num(k)>=5
                    stay_num(k)=0;
                    ai(k,:)=zeros(1,D);
                    f_pbest(k,:)=k.*ones(1,D); 
                    ar=randperm(D);
                    ai(k,ar(1:m(k)))=1;
                    fi1=ceil(ps*rand(1,D));
                    fi2=ceil(ps*rand(1,D));
                    fi=(pbestval(fi1)<pbestval(fi2))'.*fi1+(pbestval(fi1)>=pbestval(fi2))'.*fi2;
                    bi=ceil(rand(1,D)-1+Pc(k));
                    if bi==zeros(1,D),rc=randperm(D);
                        bi(rc(1))=1;
                    end
                    f_pbest(k,:)=bi.*fi+(1-bi).*f_pbest(k,:);
                    if sum(sum(f_pbest < 1)) > 0
                        k
                    end
               end

                for dimcnt=1:D
                    tmp = f_pbest(k,dimcnt);
                    pbest_f(k,dimcnt)=pbest(tmp,dimcnt);
                end
                aa(k,:)=cc(1).*(1-ai(k,:)).*rand(1,D).*(pbest_f(k,:)-pos(k,:))+cc(2).*ai(k,:).*rand(1,D).*(gbestrep(k,:)-pos(k,:));%~~~~~~~~~~~~~~~~~~~~~~  
                vel(k,:)=iwt(i).*vel(k,:)+aa(k,:); 
                vel(k,:)=(vel(k,:)>mv).*mv+(vel(k,:)<=mv).*vel(k,:); 
                vel(k,:)=(vel(k,:)<(-mv)).*(-mv)+(vel(k,:)>=(-mv)).*vel(k,:);
                pos(k,:)=pos(k,:)+vel(k,:); 
                pos(k,:) = boundConstraint(pos(k,:),lu);
               
                e(k,1)=benchmark_func(pos(k,:), problem);
                fitcount=fitcount+1;
                tmp=(pbestval(k)<=e(k));
                if tmp==1
                    stay_num(k)=stay_num(k)+1;
                end
                temp=repmat(tmp,1,D);
                pbest(k,:)=temp.*pbest(k,:)+(1-temp).*pos(k,:);
                pbestval(k)=tmp.*pbestval(k)+(1-tmp).*e(k);%update the pbest
                if pbestval(k)<gbestval
                    gbest=pbest(k,:);
                    gbestval=pbestval(k);
                    gbestrep=repmat(gbest,ps,1);%update the gbest
                end
                if fitcount==10000*0.1||mod(fitcount,10000)==0
                    RunValue(run,count)=gbestval;
                    Para(count,:)=gbest;
                    count=count+1;
                    fprintf('Algorithm:%s problemIndex:%d Run:%d FES:%d Best:%g\n','CLPSO',problem,run,fitcount,gbestval);
                end
                if TimeFlag==0
                    if gbestval <=TEV %��С�ڵ��ڸ�������ֵʱ���������۵Ĵ���%
                        TempFES=fitcount;
                        TimeFlag=1;
                    end
                end

            end
            if fitcount >= FESMAX
                break;
            end
            if (i==me) && (fitcount < FESMAX)
                i=i-1;
            end
         end
         t2=clock;
        RunTime(run)=etime(t2,t1);
        RunResult(run)=gbestval;
        RunFES(run)=TempFES;
        RunOptimization(run,1:D)=gbest;
        RunParameter=Para; 
    end
     
end

