function  plotFunc()
% %r  ��    g    �� b     �� c   ����
% %m  �Ϻ�   y  ��  k   ��   w   ��
% %v?����������   ^?����������   *?�Ǻ�   p?�����   +?�Ӻ�h?������??
% % +?�Ӻ�h?������ o Բs ������ 
    load("DE.mat"); DE = TestValue;
    load("PSO.mat"); PSO = TestValue;
    load("SLPSO.mat"); SLPSO = TestValue;
    load("EPSDE.mat"); EPSDE = TestValue;
    load("MFO.mat"); MFO = TestValue;
    load("AMFO.mat"); AMFO = TestValue;
    load("RLDE.mat"); RLDE = TestValue;
    load("ASDE.mat"); ASDE = TestValue;
       
    for i = 5:-1:1
        figure(i);
        
        tmp1 = DE{i,1};
        tmp2 = PSO{i,1};
        tmp3 = SLPSO{i,1};
        tmp4 = EPSDE{i,1};
        tmp5 = MFO{i,1};
        tmp6 = AMFO{i,1};
        tmp7 = RLDE{i,1};
        tmp8 = ASDE{i,1};
        
        [~,py] = size(tmp5);
        j = 1:py;
        plot(j,log(tmp1(1:py)),"r-o"); hold on;  grid on;
        plot(j,log(tmp2(1:py)),"k-v"); hold on;  grid on; 
        plot(j,log(tmp3(1:py)),"g-square"); hold on;  grid on; 
        plot(j,log(tmp4(1:py)),"c-^"); hold on;  grid on; 
        plot(j,log(tmp5(1:py)),"r-v"); hold on;  grid on;
        plot(j,log(tmp6(1:py)),"k-square"); hold on;  grid on; 
        plot(j,log(tmp7(1:py)),"g-^"); hold on;  grid on; 
        plot(j,log(tmp8(1:py)),"c-o"); hold on;  grid on;
        

        xlabel("Sampling point");
        ylabel("log(fitness)");
        titleName = sprintf("PV-F%s",num2str(i));
        title(titleName);
        legend("DE","PSO","SLPSO", "EPSDE","MFO","AMFO","RLDE", "ASDE");
         box on;
    end
end

