function f=benchmark_func(x,func_num)
    f = zeros(size(x,1),1);
    for i = 1:size(x,1)
        f(i,1) = ModelFunction(func_num,x(i,:));
    end
end