function lu=Boundary(problem,D)
        lu = zeros(2,D);
        if problem == 1
            lu(1,5) = 1;
            
            lu(2,1) = 1;
            lu(2,2) = 1e-6;
            lu(2,3) = 0.5;
            lu(2,4) = 100;
            lu(2,5) = 2;
        elseif problem == 2
            lu(1,5) = 1;
            lu(1,7) = 1;
            
            lu(2,1) = 1;
            lu(2,2) = 1e-6;
            lu(2,3) = 0.5;
            lu(2,4) = 100;
            lu(2,5) = 2;
            lu(2,6) = 1e-6;
            lu(2,7) = 2;
        elseif problem == 3
            lu(2,1) = 2;
            lu(2,2) = 5e-5;
            lu(2,3) = 2;
            lu(2,4) = 2000;
            lu(2,5) = 50;

            lu(1,5) = 1;
        elseif problem == 4 
            lu(2,1) = 2;
            lu(2,2) = 5e-5;
            lu(2,3) = 0.36;
            lu(2,4) = 1000;
            lu(2,5) = 60;
 
            lu(1,5) = 1;
        elseif problem == 5
            lu(2,1) = 8;
            lu(2,2) = 5e-5;
            lu(2,3) = 0.36;
            lu(2,4) = 1500;
            lu(2,5) = 50;

            lu(1,5) = 1;
        end
end