function D=Dim(problem)
    if problem == 1
        D=5;
    elseif problem == 2
        D=7;
    elseif problem == 3
        D=5;
    elseif problem == 4
        D=5;
    elseif problem == 5
        D=5;
end