function All_Run()
    clc
    clear all
    close all
    format long
    format compact
    addpath('Public');
    addpath('MFO');
    addpath('PSO');
    addpath('DEs');
    addpath('PV_problems');
    TEV=Error(Dim(1));
    runmax=25; 
    Fun_Num=5;

    %�㷨�ڲ�����
    N=100;               %population size, The N of both MPEDE and FBA_MPEDE_S is set 250

   % 1��DE,  2:EPSDE, 13:ASDE, 4:PSO, 5:SLPSO, 6:MFO, 7:AMFO, 8:RLDE
    for algorithm=1:8
        Datime = date
        TestFitness=[];
        TestResult=[];
        TestValue={};
        TestTime=[];
        TestRatio=[];
        TestFES=[];
        TestOptimization={}; 
        TestParameter={};
        switch algorithm
            %% DE
            case 1
                for problem=1:Fun_Num
                    [RunResult,RunValue,RunTime,RunFES,RunOptimization,RunParameter]=DE(problem,N,runmax);
                    sign=(RunResult<=TEV(problem));
                    Ratio=sum(sign)/runmax;
                    FES=sign.*RunFES;
                    TestFitness=[TestFitness;RunResult];
                    TestResult=[TestResult;min(RunResult) max(RunResult) median(RunResult) mean(RunResult) std(RunResult)];
                    TestValue=[TestValue;mean(RunValue)];
                    TestTime=[TestTime;mean(RunTime)];
                    TestRatio=[TestRatio;Ratio];
                    TestFES=[TestFES;mean(FES)];
                    TestOptimization=[TestOptimization;RunOptimization];
                    TestParameter=[TestParameter;RunParameter];
                end
                Test=sprintf('TestFitness/%s.mat','DE');
                save(Test,'TestFitness');
                Test=sprintf('TestResult/%s.mat','DE');
                save(Test,'TestResult');
                Test=sprintf('TestValue_FES/%s.mat','DE');
                save(Test,'TestValue');
                Test=sprintf('TestTime/%s.mat','DE');
                save(Test,'TestTime');
                Test=sprintf('TestRatio/%s.mat','DE');
                save(Test,'TestRatio');
                Test=sprintf('TestFES/%s.mat','DE');
                save(Test,'TestFES');
                Test=sprintf('TestOptimization/%s.mat','DE');
                save(Test,'TestOptimization');
                Test=sprintf('TestParameter_FES/%s.mat','DE');
                save(Test,'TestParameter');
         %% EPSDE   
            case 2
                for problem=1:Fun_Num
                    [RunResult,RunValue,RunTime,RunFES,RunOptimization,RunParameter]=EPSDE(problem,N,runmax);
                    sign=(RunResult<=TEV(problem));
                    Ratio=sum(sign)/runmax;
                    FES=sign.*RunFES;
                    TestFitness=[TestFitness;RunResult];
                    TestResult=[TestResult;min(RunResult) max(RunResult) median(RunResult) mean(RunResult) std(RunResult)];
                    TestValue=[TestValue;mean(RunValue)];
                    TestTime=[TestTime;mean(RunTime)];
                    TestRatio=[TestRatio;Ratio];
                    TestFES=[TestFES;mean(FES)];
                    TestOptimization=[TestOptimization;RunOptimization];
                    TestParameter=[TestParameter;RunParameter];
                end
                Test=sprintf('TestFitness/%s.mat','EPSDE');
                save(Test,'TestFitness');
                Test=sprintf('TestResult/%s.mat','EPSDE');
                save(Test,'TestResult');
                Test=sprintf('TestValue_FES/%s.mat','EPSDE');
                save(Test,'TestValue');
                Test=sprintf('TestTime/%s.mat','EPSDE');
                save(Test,'TestTime');
                Test=sprintf('TestRatio/%s.mat','EPSDE');
                save(Test,'TestRatio');
                Test=sprintf('TestFES/%s.mat','EPSDE');
                save(Test,'TestFES');
                Test=sprintf('TestOptimization/%s.mat','EPSDE');
                save(Test,'TestOptimization');
                Test=sprintf('TestParameter_FES/%s.mat','EPSDE');
                save(Test,'TestParameter');

             %% MPEDE   
            case 7
                for problem=1:Fun_Num
                    [RunResult,RunValue,RunTime,RunFES,RunOptimization,RunParameter]=MPEDE(problem,250,runmax);
                    sign=(RunResult<=TEV(problem));
                    Ratio=sum(sign)/runmax;
                    FES=sign.*RunFES;
                    TestFitness=[TestFitness;RunResult];
                    TestResult=[TestResult;min(RunResult) max(RunResult) median(RunResult) mean(RunResult) std(RunResult)];
                    TestValue=[TestValue;mean(RunValue)];
                    TestTime=[TestTime;mean(RunTime)];
                    TestRatio=[TestRatio;Ratio];
                    TestFES=[TestFES;mean(FES)];
                    TestOptimization=[TestOptimization;RunOptimization];
                    TestParameter=[TestParameter;RunParameter];
                end
                Test=sprintf('TestFitness/%s.mat','MPEDE');
                save(Test,'TestFitness');
                Test=sprintf('TestResult/%s.mat','MPEDE');
                save(Test,'TestResult');
                Test=sprintf('TestValue_FES/%s.mat','MPEDE');
                save(Test,'TestValue');
                Test=sprintf('TestTime/%s.mat','MPEDE');
                save(Test,'TestTime');
                Test=sprintf('TestRatio/%s.mat','MPEDE');
                save(Test,'TestRatio');
                Test=sprintf('TestFES/%s.mat','MPEDE');
                save(Test,'TestFES');
                Test=sprintf('TestOptimization/%s.mat','MPEDE');
                save(Test,'TestOptimization');
                Test=sprintf('TestParameter_FES/%s.mat','MPEDE');
                save(Test,'TestParameter');
         %% ASDE
             case 3
                for c = [0.3]
                    TestFitness=[];
                    TestResult=[];
                    TestValue={};
                    TestTime=[];
                    TestRatio=[];
                    TestFES=[];
                    TestOptimization={}; 
                    TestParameter={};
%                     name = sprintf('ASDE_e1_c%s', int2str(c*10));
                    name = "ASDE";
                    for problem=1:Fun_Num
                        [RunResult,RunValue,RunTime,RunFES,RunOptimization,RunParameter]=ASDE(problem,N,runmax,c);
                        sign=(RunResult<=TEV(problem));
                        Ratio=sum(sign)/runmax;
                        FES=sign.*RunFES;
                        TestFitness=[TestFitness;RunResult];
                        TestResult=[TestResult;min(RunResult) max(RunResult) median(RunResult) mean(RunResult) std(RunResult)];
                        TestValue=[TestValue;mean(RunValue)];
                        TestTime=[TestTime;mean(RunTime)];
                        TestRatio=[TestRatio;Ratio];
                        TestFES=[TestFES;mean(FES)];
                        TestOptimization=[TestOptimization;RunOptimization];
                        TestParameter=[TestParameter;RunParameter];
                    end
                    Test=sprintf('TestFitness/%s.mat',name);
                    save(Test,'TestFitness');
                    Test=sprintf('TestResult/%s.mat',name); 
                    save(Test,'TestResult');
                    Test=sprintf('TestValue_FES/%s.mat',name);
                    save(Test,'TestValue');
                    Test=sprintf('TestTime/%s.mat',name);
                    save(Test,'TestTime');
                    Test=sprintf('TestRatio/%s.mat',name);
                    save(Test,'TestRatio');
                    Test=sprintf('TestFES/%s.mat',name);
                    save(Test,'TestFES');
                    Test=sprintf('TestOptimization/%s.mat',name);
                    save(Test,'TestOptimization');
                    Test=sprintf('TestParameter_FES/%s.mat',name);
                    save(Test,'TestParameter');
                end
            %% PSO
            case 4
                name = "PSO";
                for problem=1:Fun_Num
                    [RunResult,RunValue,RunTime,RunFES,RunOptimization,RunParameter]=PSO(problem,N,runmax);
                    sign=(RunResult<=TEV(problem));
                    Ratio=sum(sign)/runmax;
                    FES=sign.*RunFES;
                    TestFitness=[TestFitness;RunResult];
                    TestResult=[TestResult;min(RunResult) max(RunResult) median(RunResult) mean(RunResult) std(RunResult)];
                    TestValue=[TestValue;mean(RunValue)];
                    TestTime=[TestTime;mean(RunTime)];
                    TestRatio=[TestRatio;Ratio];
                    TestFES=[TestFES;mean(FES)];
                    TestOptimization=[TestOptimization;RunOptimization];
                    TestParameter=[TestParameter;RunParameter];
                end
                Test=sprintf('TestFitness/%s.mat',name);
                save(Test,'TestFitness');
                Test=sprintf('TestResult/%s.mat',name); 
                save(Test,'TestResult');
                Test=sprintf('TestValue_FES/%s.mat',name);
                save(Test,'TestValue');
                Test=sprintf('TestTime/%s.mat',name);
                save(Test,'TestTime');
                Test=sprintf('TestRatio/%s.mat',name);
                save(Test,'TestRatio');
                Test=sprintf('TestFES/%s.mat',name);
                save(Test,'TestFES');
                Test=sprintf('TestOptimization/%s.mat',name);
                save(Test,'TestOptimization');
                Test=sprintf('TestParameter_FES/%s.mat',name);
                save(Test,'TestParameter');

            %% SLPSO
            case 5
                name = "SLPSO";
                for problem=1:Fun_Num
                    [RunResult,RunValue,RunTime,RunFES,RunOptimization,RunParameter]=SLPSO(problem,N,runmax);
                    sign=(RunResult<=TEV(problem));
                    Ratio=sum(sign)/runmax;
                    FES=sign.*RunFES;
                    TestFitness=[TestFitness;RunResult];
                    TestResult=[TestResult;min(RunResult) max(RunResult) median(RunResult) mean(RunResult) std(RunResult)];
                    TestValue=[TestValue;mean(RunValue)];
                    TestTime=[TestTime;mean(RunTime)];
                    TestRatio=[TestRatio;Ratio];
                    TestFES=[TestFES;mean(FES)];
                    TestOptimization=[TestOptimization;RunOptimization];
                    TestParameter=[TestParameter;RunParameter];
                end
                Test=sprintf('TestFitness/%s.mat',name);
                save(Test,'TestFitness');
                Test=sprintf('TestResult/%s.mat',name); 
                save(Test,'TestResult');
                Test=sprintf('TestValue_FES/%s.mat',name);
                save(Test,'TestValue');
                Test=sprintf('TestTime/%s.mat',name);
                save(Test,'TestTime');
                Test=sprintf('TestRatio/%s.mat',name);
                save(Test,'TestRatio');
                Test=sprintf('TestFES/%s.mat',name);
                save(Test,'TestFES');
                Test=sprintf('TestOptimization/%s.mat',name);
                save(Test,'TestOptimization');
                Test=sprintf('TestParameter_FES/%s.mat',name);
                save(Test,'TestParameter');


             %% MFO
            case 6
                name = "MFO";
                for problem=1:Fun_Num
                    [RunResult,RunValue,RunTime,RunFES,RunOptimization,RunParameter]=MFO(problem,N,runmax);
                    sign=(RunResult<=TEV(problem));
                    Ratio=sum(sign)/runmax;
                    FES=sign.*RunFES;
                    TestFitness=[TestFitness;RunResult];
                    TestResult=[TestResult;min(RunResult) max(RunResult) median(RunResult) mean(RunResult) std(RunResult)];
                    TestValue=[TestValue;mean(RunValue)];
                    TestTime=[TestTime;mean(RunTime)];
                    TestRatio=[TestRatio;Ratio];
                    TestFES=[TestFES;mean(FES)];
                    TestOptimization=[TestOptimization;RunOptimization];
                    TestParameter=[TestParameter;RunParameter];
                end
                Test=sprintf('TestFitness/%s.mat',name);
                save(Test,'TestFitness');
                Test=sprintf('TestResult/%s.mat',name); 
                save(Test,'TestResult');
                Test=sprintf('TestValue_FES/%s.mat',name);
                save(Test,'TestValue');
                Test=sprintf('TestTime/%s.mat',name);
                save(Test,'TestTime');
                Test=sprintf('TestRatio/%s.mat',name);
                save(Test,'TestRatio');
                Test=sprintf('TestFES/%s.mat',name);
                save(Test,'TestFES');
                Test=sprintf('TestOptimization/%s.mat',name);
                save(Test,'TestOptimization');
                Test=sprintf('TestParameter_FES/%s.mat',name);
                save(Test,'TestParameter');

           %% AMFO
            case 7
                name = "AMFO";
                for problem=1:Fun_Num
                    [RunResult,RunValue,RunTime,RunFES,RunOptimization,RunParameter]=AMFO(problem,N,runmax);
                    sign=(RunResult<=TEV(problem));
                    Ratio=sum(sign)/runmax;
                    FES=sign.*RunFES;
                    TestFitness=[TestFitness;RunResult];
                    TestResult=[TestResult;min(RunResult) max(RunResult) median(RunResult) mean(RunResult) std(RunResult)];
                    TestValue=[TestValue;mean(RunValue)];
                    TestTime=[TestTime;mean(RunTime)];
                    TestRatio=[TestRatio;Ratio];
                    TestFES=[TestFES;mean(FES)];
                    TestOptimization=[TestOptimization;RunOptimization];
                    TestParameter=[TestParameter;RunParameter];
                end
                Test=sprintf('TestFitness/%s.mat',name);
                save(Test,'TestFitness');
                Test=sprintf('TestResult/%s.mat',name); 
                save(Test,'TestResult');
                Test=sprintf('TestValue_FES/%s.mat',name);
                save(Test,'TestValue');
                Test=sprintf('TestTime/%s.mat',name);
                save(Test,'TestTime');
                Test=sprintf('TestRatio/%s.mat',name);
                save(Test,'TestRatio');
                Test=sprintf('TestFES/%s.mat',name);
                save(Test,'TestFES');
                Test=sprintf('TestOptimization/%s.mat',name);
                save(Test,'TestOptimization');
                Test=sprintf('TestParameter_FES/%s.mat',name);
                save(Test,'TestParameter');
            %% RLDE
            case 8
                name = "RLDE";
                for problem=1:Fun_Num
                    [RunResult,RunValue,RunTime,RunFES,RunOptimization,RunParameter]=RLDE(problem,N,runmax);
                    sign=(RunResult<=TEV(problem));
                    Ratio=sum(sign)/runmax;
                    FES=sign.*RunFES;
                    TestFitness=[TestFitness;RunResult];
                    TestResult=[TestResult;min(RunResult) max(RunResult) median(RunResult) mean(RunResult) std(RunResult)];
                    TestValue=[TestValue;mean(RunValue)];
                    TestTime=[TestTime;mean(RunTime)];
                    TestRatio=[TestRatio;Ratio];
                    TestFES=[TestFES;mean(FES)];
                    TestOptimization=[TestOptimization;RunOptimization];
                    TestParameter=[TestParameter;RunParameter];
                end
                Test=sprintf('TestFitness/%s.mat',name);
                save(Test,'TestFitness');
                Test=sprintf('TestResult/%s.mat',name); 
                save(Test,'TestResult');
                Test=sprintf('TestValue_FES/%s.mat',name);
                save(Test,'TestValue');
                Test=sprintf('TestTime/%s.mat',name);
                save(Test,'TestTime');
                Test=sprintf('TestRatio/%s.mat',name);
                save(Test,'TestRatio');
                Test=sprintf('TestFES/%s.mat',name);
                save(Test,'TestFES');
                Test=sprintf('TestOptimization/%s.mat',name);
                save(Test,'TestOptimization');
                Test=sprintf('TestParameter_FES/%s.mat',name);
                save(Test,'TestParameter');
        end       
    end
    rmpath('Public');
    rmpath('DEs');
    rmpath('MFO');
    rmpath('PSO');
    rmpath('PV_problems');
end

