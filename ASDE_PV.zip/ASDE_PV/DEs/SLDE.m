%% State learning based Different Evolution with adaptive control parameters
% written by ZhenYu Wang on 2021/09/24
%problem: the serial number of testing function recorded in "Public\benchmark_func.m"
%N: the population size
%runmax: the number of the algorithm runs
%RunResult: the  optimal value produced by each algorithm runs
%RunOptimization: the optimal value produced by reach algorithm runs
%RunValue: the fitness of optimal value produced by each 10000 FES
%RunParameter:the optimal value produced by each 10000 FES
%RunTime: the time spent by each algorithm runs
%RunFES: the FES required to satisfy the conditions
function [RunResult,RunValue,RunTime,RunFES,RunOptimization,RunParameter]=SLDE(problem,N,runmax,c)
    'SLDE'
    D=Dim(problem);%13-16�е���˼�ο�CEP
    lu=Boundary(problem,D);
    tempTEV=Error(D);
    TEV = tempTEV(problem);
    FESMAX=D*10000;
    RunOptimization=zeros(runmax,D);
    for run=1:runmax
        TimeFlag=0;
        TempFES=FESMAX;
        t1=clock;
%         CR=0.9;%�������
%         F=0.5;%���첽��������߶ȣ�
        c = 0.2;
        epsilon = 0.1;
        intervalNum = 5;
        intervalSize = 1/intervalNum;
        actionNum = intervalNum^2;
        
        pop=Initpop(N,D,lu);%��Ⱥ��ʼ�����ο�CEP
        fitness=benchmark_func(pop,problem);%����ÿһ������ĺ���ֵ���ο�CEP
        best = min(fitness);
        FES=N;%��ǰ�ĺ������۴������������Ѽ���Ĵ���
        stagnation = 0;
        k=1;
        Qtable = cell(1,2);
        Qtable{1,1} = ones(N,3) .* inf;
        Qtable{1,2} = zeros(N,actionNum);
        pos = 1;
        
        %��������ռ�
        r1 = zeros(N,1);
        r2 = zeros(N,1);
        r3 = zeros(N,1);
        F = zeros(N,1);
        CR = zeros(N,1);
        while FES<=FESMAX
            % Calculating state featur of current population
            currentPopStd = sum(std(pop));
            currentFitStd = std(fitness);
            currentState = [currentPopStd, currentFitStd, stagnation];
            % state matching 
            try
                similarity = pdist2(Qtable{1,1},currentState,'mahal'); %Calculating feature similarity by using Mahalanobis distance
            catch ME %#ok<NASGU>
                similarity = sqrt(sum((currentState - Qtable{1,1}).^2,2)); %Calculating feature similarity by using Euclidean distance
            end
            [~, I] = min(similarity);
            currentQtable = Qtable{1,2}(I,:);
            %selecting action by epsilon strategy
            action = zeros(N,1);
            mask = rand(N,1) < epsilon;
            [maxQ,~] = max(currentQtable);
            index = 1:actionNum;
            tmpIndex = index(currentQtable == maxQ);
            action(~mask,1) = tmpIndex(ceil(rand(sum(~mask),1) * length(tmpIndex)));
            action(mask,1) = ceil(rand(sum(mask),1) * actionNum);
            %decoding aciton to scale factor F
            for i = 1:N
                F(i) = floor((action(i,1) - 1)/intervalNum) * intervalSize + rand * intervalSize;
                CR(i) = mod(action(i,1) - 1,intervalNum) * intervalSize + rand * intervalSize;
            end
            
            for i = 1:N
                temp = randperm(N);
                temp(temp == i) = [];
                r1(i) = temp(1);
                r2(i) = temp(2);
                r3(i) = temp(3);
            end
            %mutation operator
            v = pop(r1,:) + F.* (pop(r2,:) - pop(r3,:));
            v = boundConstraint(v,lu);
            mask = rand(N, D) < CR;
            mask(:, ceil(rand(N,1)*D)) = true; % last one dimension data performs crossover operator
            u = pop;
            u(mask) = v(mask);
            newFitness = benchmark_func(u,problem);
            differenceValue = fitness - newFitness;
%             differenceValue(differenceValue < 0) = 0;   % if improvement < 0, improvement is set 0.
            mask = newFitness <= fitness;
            pop(mask,:) = u(mask,:);
            fitness(mask,:) = newFitness(mask,:);
            currentbest = min(fitness);
            if currentbest < best
                best = currentbest;
                stagnation = 0;
            else
                stagnation = stagnation + 1;
            end
            %update Q table
            for a = 1:actionNum
                tmp = (action == a) .* (differenceValue > 0 );
                mask = tmp == 1;
%                 mask = action == a;
                reward = mean(differenceValue(mask));
                if ~isnan(reward)
                    currentQtable(1,a) = (1 - c) * currentQtable(1,a) + c * reward;
                end
            end
            Qtable{1,1}(pos,:) = currentState;
            Qtable{1,2}(pos,:) = currentQtable;
            pos = pos + 1;
            if pos > N
                pos = 1;
            end
            %% visualization
            for i = 1:N
                FES = FES+1;
                if FES == 10000*0.1 || mod(FES,10000) == 0
                    [kk,ll] = min(fitness);
                    RunValue(run,k) = kk;
                    Para(k,:) = pop(ll,:);
                    k=k+1;
                    fprintf('Algorithm:%s problemIndex:%d Run:%d FES:%d Best:%g\n','SLDE',problem,run,FES,kk);
                end
                if TimeFlag == 0
                    if min(fitness) <= TEV
                        TempFES = FES;
                        TimeFlag = 1;
                    end
                end
            end
        end
        [kk,ll]=min(fitness);
        gbest=pop(ll,:);
        t2=clock;
        RunTime(run)=etime(t2,t1);
        RunResult(run)=kk;
        RunFES(run)=TempFES;
        RunOptimization(run,1:D)=gbest;
        RunParameter{run}=Para;
    end
end