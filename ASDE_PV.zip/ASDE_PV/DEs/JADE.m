function [RunResult,RunValue,RunTime,RunFES,RunOptimization,RunParameter]=JADE(problem,N,runmax)
    'JADE'
    D=Dim(problem);%3-6�е���˼�ο�CEP
    lu=Boundary(problem,D);
    tempTEV=Error(D);
    TEV = tempTEV(problem);
    FESMAX=D*10000;
    RunOptimization=zeros(runmax,D);

    for run = 1:runmax
        TimeFlag=0;
        TempFES=FESMAX;
        t1=clock;
        % Initialize the main population
        popold = Initpop(N,D,lu);
        valParents = benchmark_func(popold, problem);
        c = 1/10;
        p = 0.05;
        CRm = 0.5;
        Fm = 0.5;
        goodCR=[];
        goodF=[];
        Afactor = 1;

        archive.NP = Afactor * N; % the maximum size of the archive
        archive.pop = zeros(0, D); % the solutions stored in te archive
        archive.funvalues = zeros(0, 1); % the function value of the archived solutions

        %% the values and indices of the best solutions
        [valBest, indBest] = sort(valParents, 'ascend');

        FES = N;
        k = 1;
        while FES < FESMAX %& min(fit)>error_value(problem)

            pop = popold; % the old population becomes the current population

            if FES > 1 && ~isempty(goodCR) && sum(goodF) > 0 % If goodF and goodCR are empty, pause the update
                CRm = (1 - c) * CRm + c * mean(goodCR);
                Fm = (1 - c) * Fm + c * sum(goodF .^ 2) / sum(goodF); % Lehmer mean
%                 if mod(FES,1000) == 0;
%                      count =1;
%                  end
            end

            % Generate CR according to a normal distribution with mean CRm, and std 0.1
            % Generate F according to a cauchy distribution with location parameter Fm, and scale parameter 0.1
            [F, CR] = randFCR(N, CRm, 0.1, Fm, 0.1);

            r0 = [1 : N];
            popAll = [pop; archive.pop];
            [r1, r2] = gnR1R2(N, size(popAll, 1), r0);

            % Find the p-best solutions
            pNP = max(round(p * N), 2); % choose at least two best solutions
            randindex = ceil(rand(1, N) * pNP); % select from [1, 2, 3, ..., pNP]
            randindex = max(1, randindex); % to avoid the problem that rand = 0 and thus ceil(rand) = 0
            pbest = pop(indBest(randindex), :); % randomly choose one of the top 100p% solutions

            % == == == == == == == == == == == == == == == Mutation == == == == == == == == == == == == ==
            vi = pop + F(:, ones(1, D)) .* (pbest - pop + pop(r1, :) - popAll(r2, :));

            vi = boundConstraint(vi,lu);

            % == == == == = Crossover == == == == =
            mask = rand(N, D) > CR(:, ones(1, D)); % mask is used to indicate which elements of ui comes from the parent
            rows = (1 : N)'; cols = floor(rand(N, 1) * D)+1; % choose one position where the element of ui doesn't come from the parent
            jrand = sub2ind([N D], rows, cols); mask(jrand) = false;
            ui = vi; ui(mask) = pop(mask);

            valOffspring = benchmark_func(ui, problem);

            % == == == == == == == == == == == == == == == Selection == == == == == == == == == == == == ==
            % I == 1: the parent is better; I == 2: the offspring is better
            [valParents, I] = min([valParents, valOffspring], [], 2);
            popold = pop;

            archive = updateArchive(archive, popold(I == 2, :), valParents(I == 2));

            popold(I == 2, :) = ui(I == 2, :);
            valParents(I == 2) = valOffspring(I == 2);
            goodCR = CR(I == 2);
            goodF = F(I == 2);

            [valBest indBest] = sort(valParents, 'ascend');
            for i=1:N
                FES=FES+1;
                if FES==10000*0.1||mod(FES,10000)==0
                    [kk,ll]=min(valParents);
                    RunValue(run,k)=kk;
                    Para(k,:)=popold(ll,:);
                    k=k+1;
                    fprintf('Algorithm:%s problemIndex:%d Run:%d FES:%d Best:%g\n','JADE',problem,run,FES,kk);
                end
                if TimeFlag==0
                    if min(valParents)<=TEV
                        TempFES=FES;
                        TimeFlag=1;
                    end
                end
            end

        end
        [kk,ll]=min(valParents);
        gbest=popold(ll,:);
        t2=clock;
        RunTime(run)=etime(t2,t1);
        RunResult(run)=kk;
        RunFES(run)=TempFES;
        RunOptimization(run,1:D)=gbest;
        RunParameter{run}=Para;
    end
end


function [F,CR] = randFCR(NP, CRm, CRsigma, Fm,  Fsigma)

% this function generate CR according to a normal distribution with mean "CRm" and sigma "CRsigma"
%           If CR > 1, set CR = 1. If CR < 0, set CR = 0.
% this function generate F  according to a cauchy distribution with location parameter "Fm" and scale parameter "Fsigma"
%           If F > 1, set F = 1. If F <= 0, regenrate F.
%
% Version: 1.1   Date: 11/20/2007
% Written by Jingqiao Zhang (jingqiao@gmail.com)

    %% generate CR
    CR = CRm + CRsigma * randn(NP, 1);
    CR = min(1, max(0, CR));                % truncated to [0 1]

    %% generate F
    F = randCauchy(NP, 1, Fm, Fsigma);
    F = min(1, F);                          % truncation

    % we don't want F = 0. So, if F<=0, we regenerate F (instead of trucating it to 0)
    pos = find(F <= 0);
    while ~ isempty(pos)
        F(pos) = randCauchy(length(pos), 1, Fm, Fsigma);
        F = min(1, F);                      % truncation
        pos = find(F <= 0);
    end
end

% Cauchy distribution: cauchypdf = @(x, mu, delta) 1/pi*delta./((x-mu).^2+delta^2)
function result = randCauchy(m, n, mu, delta)

% http://en.wikipedia.org/wiki/Cauchy_distribution
result = mu + delta * tan(pi * (rand(m, n) - 0.5));
end

function [r1, r2] = gnR1R2(NP1, NP2, r0)
    N=length(r0);
    for i = 1:N
        if rand <= NP1/NP2
            temp=randperm(NP1);
            r1r2=temp(1:2);
            r1r2(find(r1r2==r0(i)))=temp(3);
            r1(i)=r1r2(1);
            r2(i)=r1r2(2);
        else
            temp=randperm(NP1);
            temp(find(temp==r0(i)))=[];
            r1(i)=temp(1);
            r2(i)=floor(rand*(NP2-NP1))+NP1+1;
        end
    end
end