%% State learning based Reinforcement learning optimized Different Evolution (SLCODE)
% written by ZhenYu Wang on 2021/09/24
%problem: the serial number of testing function recorded in "Public\benchmark_func.m"
%N: the population size
%runmax: the number of the algorithm runs
%RunResult: the  optimal value produced by each algorithm runs
%RunOptimization: the optimal value produced by reach algorithm runs
%RunValue: the fitness of optimal value produced by each 10000 FES
%RunParameter:the optimal value produced by each 10000 FES
%RunTime: the time spent by each algorithm runs
%RunFES: the FES required to satisfy the conditions
function [RunResult,RunValue,RunTime,RunFES,RunOptimization,RunParameter]=SLCODE(problem,N,runmax,e)
    'SLCODE'
    D=Dim(problem);%13-16�е���˼�ο�CEP
    lu=Boundary(problem,D);
    tempTEV=Error(D);
    TEV = tempTEV(problem);
    FESMAX=D*10000;
    RunOptimization=zeros(runmax,D);
    for run=1:runmax
        TimeFlag=0;
        TempFES=FESMAX;
        t1=clock;
        epsilon = 0.1;
        gamma = 0.8;
        alpha = 0.9;
        c = 0.1;

        parameter = [1, 0.1; 1, 0.9; 0.8 0.2;];
        actionNum = 9;
        pop=Initpop(N,D,lu);%��Ⱥ��ʼ�����ο�CEP
        fitness=benchmark_func(pop,problem);%����ÿһ������ĺ���ֵ���ο�CEP
        best = min(fitness);
        FES=N;%��ǰ�ĺ������۴������������Ѽ���Ĵ���
        stagnation = 0;
        k=1;
        Qtable = cell(1,2);
        Qtable{1,1} = ones(N,3) .* inf;
        Qtable{1,2} = zeros(N,actionNum);
        pos = 1;
        
        r1 = zeros(N,1);
        r2 = zeros(N,1);
        r3 = zeros(N,1);
        r4 = zeros(N,1);
        r5 = zeros(N,1);
        while FES<=FESMAX
%             epsilon = max((1 - FES/FESMAX) * 0.5, 0.1);
            
            % Calculating state featur of current population
            currentPopStd = sum(std(pop));
            currentFitStd = std(fitness);
            currentState = [currentPopStd, currentFitStd, stagnation];
            % state matching 
            try
                similarity = pdist2(Qtable{1,1},currentState,'mahal'); %Calculating feature similarity by using Mahalanobis distance
            catch ME %#ok<NASGU>
                similarity = sqrt(sum((currentState - Qtable{1,1}).^2,2)); %Calculating feature similarity by using Euclidean distance
            end
            [~, I] = min(similarity);
            currentQtable = Qtable{1,2}(I,:);

            %selecting action by epsilon strategy
            if rand < epsilon
                [maxQ,~] = max(currentQtable);
                index = 1:actionNum; 
                tmpIndex = index(currentQtable == maxQ);
                currentAction = tmpIndex(ceil(rand * length(tmpIndex)));
            else
                currentAction = ceil(rand * actionNum);
            end
            %decoding aciton to scale factor F
            strategy = floor((currentAction - 1)/3)+1;
            F = parameter(mod(currentAction - 1,3)+1,1);
            CR = parameter(mod(currentAction - 1,3)+1,2);
            
            
            for i = 1:N
                temp = randperm(N);
                temp(temp == i) = [];
                r1(i) = temp(1);
                r2(i) = temp(2);
                r3(i) = temp(3);
                r4(i) = temp(4);
                r5(i) = temp(5);
            end
            u = pop;
            if strategy == 1
                v = pop(r1,:) + F.* (pop(r2,:) - pop(r3,:));
                mask = rand(N, D) < CR;
                for i = 1:N
                    mask(i,ceil(rand * D)) = true; % last one dimension data performs crossover operator
                end
                u(mask) = v(mask);
            elseif strategy == 2
                v = pop(r1,:) + F.* (pop(r2,:) - pop(r3,:) + pop(r4,:) - pop(r5,:));
                mask = rand(N, D) < CR;
                for i = 1:N
                    mask(i,ceil(rand * D)) = true; % last one dimension data performs crossover operator
                end
                u(mask) = v(mask);
            else
                v = pop + rand(N,1) .*(pop(r1,:) - pop(i,:)) + F.* (pop(r2,:) - pop(r3,:));
                u = pop + rand(N,1) .* (v - pop);
            end
            newFitness = benchmark_func(u,problem);
            differenceValue = fitness - newFitness;
%             differenceValue(differenceValue < 0) = 0;   % if improvement < 0, improvement is set 0.
            mask = newFitness <= fitness;
            pop(mask,:) = u(mask,:);
            fitness(mask,:) = newFitness(mask,:);
            currentbest = min(fitness);
            if currentbest < best
                best = currentbest;
                stagnation = 0;
            else
                stagnation = stagnation + 1;
            end
            reward = sum(differenceValue(mask))/N;
            %update Q table
%             currentQtable(1,currentAction) = currentQtable(1,currentAction) + alpha * (reward + gamma * maxQvalue - currentQtable(1,currentAction));
            currentQtable(1,currentAction) = (1 - c) * currentQtable(1,currentAction) + c * reward;
            Qtable{1,1}(pos,:) = currentState;
            Qtable{1,2}(pos,:) = currentQtable;
            pos = pos + 1;
            if pos > N
                pos = 1;
            end
            %% visualization
            for i = 1:N
                FES = FES+1;
                if FES == 10000*0.1 || mod(FES,10000) == 0
                    [kk,ll] = min(fitness);
                    RunValue(run,k) = kk;
                    Para(k,:) = pop(ll,:);
                    k=k+1;
                    fprintf('Algorithm:%s problemIndex:%d Run:%d FES:%d Best:%g\n','SLCODE',problem,run,FES,kk);
                end
                if TimeFlag == 0
                    if min(fitness) <= TEV
                        TempFES = FES;
                        TimeFlag = 1;
                    end
                end
            end
        end
        [kk,ll]=min(fitness);
        gbest=pop(ll,:);
        t2=clock;
        RunTime(run)=etime(t2,t1);
        RunResult(run)=kk;
        RunFES(run)=TempFES;
        RunOptimization(run,1:D)=gbest;
        RunParameter{run}=Para;
    end
end