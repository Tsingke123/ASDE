%% The Composition Different Evolution
%problem: the serial number of testing function recorded in "Public\benchmark_func.m"
%N: the population size
%runmax: the number of the algorithm runs
%RunResult: the  optimal value produced by each algorithm runs
%RunOptimization: the optimal value produced by reach algorithm runs
%RunValue: the fitness of optimal value produced by each 10000 FES
%RunParameter:the optimal value produced by each 10000 FES
%RunTime: the time spent by each algorithm runs
%RunFES: the FES required to satisfy the conditions
function [RunResult,RunValue,RunTime,RunFES,RunOptimization,RunParameter]=CODE(problem,N,runmax)
    'CODE'
    D=Dim(problem);%13-16�е���˼�ο�CEP
    lu=Boundary(problem,D);
    tempTEV=Error(D);
    TEV = tempTEV(problem);
    FESMAX=D*10000;
    RunOptimization=zeros(runmax,D);
    for run=1:runmax
        TimeFlag=0;
        TempFES=FESMAX;
        t1=clock;
%         CR=0.9;%�������
%         F=0.5;%���첽��������߶ȣ�
        parameter = [1, 0.1; 1, 0.9; 0.8 0.2;];
        pop=Initpop(N,D,lu);%��Ⱥ��ʼ�����ο�CEP
        fitness=benchmark_func(pop,problem);%����ÿһ������ĺ���ֵ���ο�CEP
        FES=N;%��ǰ�ĺ������۴������������Ѽ���Ĵ���
        k=1;
        
        r1 = zeros(N,1);
        r2 = zeros(N,1);
        r3 = zeros(N,1);
        r4 = zeros(N,1);
        r5 = zeros(N,1);
        F = zeros(N,1);
        CR = zeros(N,1);
        while FES<=FESMAX
            %DE/rand/1
            for i = 1:N
                temp = randperm(N);
                temp(temp == i) = [];
                r1(i) = temp(1);
                r2(i) = temp(2);
                r3(i) = temp(3);
                randIndex = ceil(rand(1,1) * 3);
                F(i,1) = parameter(randIndex,1);
                CR(i,1) = parameter(randIndex,2);
            end
            v1 = pop(r1,:) + F.* (pop(r2,:) - pop(r3,:));
            v1 = boundConstraint(v1,lu);
            mask = rand(N, D) < CR;
            mask(:, ceil(rand(N,1)*D)) = true; % last one dimension data performs crossover operator
            u1 = pop;
            u1(mask) = v1(mask);
            newFitness1 = benchmark_func(u1,problem);
            %DE/rand/2
            for i = 1:N
                temp = randperm(N);
                temp(temp == i) = [];
                r1(i) = temp(1);
                r2(i) = temp(2);
                r3(i) = temp(3);
                r4(i) = temp(4);
                r5(i) = temp(5);
                randIndex = ceil(rand(1,1) * 3);
                F(i,1) = parameter(randIndex,1);
                CR(i,1) = parameter(randIndex,2);
            end
            v2 = pop(r1,:) + F.* (pop(r2,:) - pop(r3,:) + pop(r4,:) - pop(r5,:));
            v2 = boundConstraint(v2,lu);
            mask = rand(N, D) < CR;
            mask(:, ceil(rand(N,1)*D)) = true; % last one dimension data performs crossover operator
            u2 = pop;
            u2(mask) = v2(mask);
            newFitness2 = benchmark_func(u2,problem);
            %DE/current-to-rand/1
            for i = 1:N
                temp = randperm(N);
                temp(temp == i) = [];
                r1(i) = temp(1);
                r2(i) = temp(2);
                r3(i) = temp(3);
                randIndex = ceil(rand(1,1) * 3);
                F(i,1) = parameter(randIndex,1);
            end
            v3 = pop + rand .*(pop(r1,:) - pop) + F.* (pop(r2,:) - pop(r3,:));
            v3 = boundConstraint(v3,lu);
            u3 = pop + rand .* (v3 - pop);
            newFitness3 = benchmark_func(u3,problem);
            
            %select operator
            [fitness, I] = min([newFitness1, newFitness2, newFitness3,fitness],[],2);
            pop(I == 1,:) = u1(I == 1,:);
            pop(I == 2,:) = u2(I == 2,:);
            pop(I == 3,:) = u3(I == 3,:);
            %% visualization
            for i = 1:3*N
                FES = FES+1;
                if FES == 10000*0.1 || mod(FES,10000) == 0
                    [kk,ll] = min(fitness);
                    RunValue(run,k) = kk;
                    Para(k,:) = pop(ll,:);
                    k=k+1;
                    fprintf('Algorithm:%s problemIndex:%d Run:%d FES:%d Best:%g\n','CODE',problem,run,FES,kk);
                end
                if TimeFlag == 0
                    if min(fitness) <= TEV
                        TempFES = FES;
                        TimeFlag = 1;
                    end
                end
            end
        end
        [kk,ll]=min(fitness);
        gbest=pop(ll,:);
        t2=clock;
        RunTime(run)=etime(t2,t1);
        RunResult(run)=kk;
        RunFES(run)=TempFES;
        RunOptimization(run,1:D)=gbest;
        RunParameter{run}=Para;
    end
end