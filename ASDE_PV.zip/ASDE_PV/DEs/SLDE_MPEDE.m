%% State learning based Different Evolution with adaptive control parameters
% written by ZhenYu Wang on 2021/09/24
%problem: the serial number of testing function recorded in "Public\benchmark_func.m"
%N: the population size
%runmax: the number of the algorithm runs
%RunResult: the  optimal value produced by each algorithm runs
%RunOptimization: the optimal value produced by reach algorithm runs
%RunValue: the fitness of optimal value produced by each 10000 FES
%RunParameter:the optimal value produced by each 10000 FES
%RunTime: the time spent by each algorithm runs
%RunFES: the FES required to satisfy the conditions
function [RunResult,RunValue,RunTime,RunFES,RunOptimization,RunParameter]=SLDE_MPEDE(problem,N,runmax,e)
    'SLDE_MPEDE'
    D=Dim(problem);%13-16�е���˼�ο�CEP
    lu=Boundary(problem,D);
    tempTEV=Error(D);
    TEV = tempTEV(problem);
    FESMAX=D*10000;
    RunOptimization=zeros(runmax,D);
    for run=1:runmax
        TimeFlag=0;
        TempFES=FESMAX;
        t1=clock;
%         CR=0.9;%�������
%         F=0.5;%���첽��������߶ȣ�
        c = 0.2;
        epsilon = e;
        intervalNum = 5;
        intervalSize = 1/intervalNum;
        actionSteps = [ intervalNum * intervalNum,intervalNum,0];
        actionNum = 3 * intervalNum^2;
        
        pop=Initpop(N,D,lu);%��Ⱥ��ʼ�����ο�CEP
        fitness=benchmark_func(pop,problem);%����ÿһ������ĺ���ֵ���ο�CEP
        best = min(fitness);
        FES=N;%��ǰ�ĺ������۴������������Ѽ���Ĵ���
        stagnation = 0;
        k=1;
        Qtable = cell(1,2);
        Qtable{1,1} = ones(N,3) .* inf;
        Qtable{1,2} = zeros(N,actionNum);
        pos = 1;
        
        archive.NP = N; % the maximum size of the archive
        archive.pop = zeros(0, D); % the solutions stored in te archive
        archive.funvalues = zeros(0, 1); % the function value of the archived solutions
        
        %��������ռ�
%         r1 = zeros(N,1);
%         r2 = zeros(N,1);
%         r3 = zeros(N,1);
        F = zeros(N,1);
        CR = zeros(N,1);
        strategy = zeros(N,1);
        while FES<=FESMAX
            % Calculating state featur of current population
            currentPopStd = sum(std(pop));
            currentFitStd = std(fitness);
            currentState = [currentPopStd, currentFitStd, stagnation];
            % state matching 
            try
                similarity = pdist2(Qtable{1,1},currentState,'mahal'); %Calculating feature similarity by using Mahalanobis distance
            catch ME %#ok<NASGU>
                similarity = sqrt(sum((currentState - Qtable{1,1}).^2,2)); %Calculating feature similarity by using Euclidean distance
            end
            [~, I] = min(similarity);
            currentQtable = Qtable{1,2}(I,:);
            %selecting action by epsilon strategy
            action = zeros(N,1);
            mask = rand(N,1) < epsilon;
            [maxQ,~] = max(currentQtable);
            index = 1:actionNum;
            tmpIndex = index(currentQtable == maxQ);
            action(~mask,1) = tmpIndex(ceil(rand(sum(~mask),1) * length(tmpIndex)));
            action(mask,1) = ceil(rand(sum(mask),1) * actionNum);
            %decoding aciton to scale factor F
            for i = 1:N
                strategy(i) = floor((action(i,1) - 1)/actionSteps(1)) + 1;
                F(i) = floor(mod(action(i,1) - 1,actionSteps(1))/intervalNum) * intervalSize + rand * intervalSize;
                CR(i) = mod(action(i,1) - 1,actionSteps(2)) * intervalSize + rand * intervalSize;
            end
            popAll = [pop; archive.pop];
            [~, sorted_index] = sort(fitness, 'ascend');
            u = pop;
            for i = 1:N
                if strategy(i) == 1
                    temp = randperm(size(popAll,1));
                    temp(temp == i) = [];
                    count = 1;
                    r1 = temp(count);
                    while r1 > N
                        count = count + 1;
                        r1 = temp(count);
                    end
                    r2 = temp(count + 1);
                    p_best_rate = rand * (0.2 - 2/N) + 2/N; %% choose at least two best solutions
                    pNP = round(p_best_rate * N); 
                    randindex = ceil(rand * pNP); %% select from [1, 2, 3, ..., pNP]
                    randindex = max(1, randindex); %% to avoid the problem that rand = 0 and thus ceil(rand) = 0
                    pbest = pop(sorted_index(randindex), :); %% randomly choose one of the top 100p% solutions
                    %mutation operator
                    v = pop(i,:) + F(i) .* (pbest - pop(i,:) + pop(r1, :) - popAll(r2, :));
                    v = boundConstraint(v,lu);
                    mask = rand(1, D) < CR(i);
                    mask(1, ceil(rand * D)) = true; % last one dimension data performs crossover operator
                    u(i,mask) = v(mask);
                elseif strategy(i) == 2
                    temp = randperm(N);
                    r1 = temp(1);
                    r2 = temp(2);
                    r3 = temp(3);
                    v = pop(r1,:) + F(i).* (pop(r2,:) - pop(r3,:));
                    v = boundConstraint(v,lu);
                    mask = rand(1, D) < CR(i);
                    mask(1, ceil(rand*D)) = true; % last one dimension data performs crossover operator
                    u(i,mask) = v(mask);
                else
                    temp = randperm(N);
                    r1 = temp(1);
                    r2 = temp(2);
                    r3 = temp(3);
                    v = pop(i,:) + rand .*(pop(r1,:) - pop(i,:)) + F(i).* (pop(r2,:) - pop(r3,:));
                    v = boundConstraint(v,lu);
                    u(i,:) = pop(i,:) + rand .* (v - pop(i,:));
                end
            end  
            newFitness = benchmark_func(u,problem);
            differenceValue = fitness - newFitness;
%             differenceValue(differenceValue < 0) = 0;   % if improvement < 0, improvement is set 0.
            mask = newFitness <= fitness;
            archive = updateArchive(archive, pop(~mask, :), fitness(~mask));
            pop(mask,:) = u(mask,:);
            fitness(mask,:) = newFitness(mask,:);
            currentbest = min(fitness);
            if currentbest < best
                best = currentbest;
                stagnation = 0;
            else
                stagnation = stagnation + 1;
            end
            %update Q table
            for a = 1:actionNum
                tmp = (action == a) .* (differenceValue > 0 );
                mask = tmp == 1;
%                 mask = action == a;
                reward = mean(differenceValue(mask));
                if ~isnan(reward)
                    currentQtable(1,a) = (1 - c) * currentQtable(1,a) + c * reward;
                end
            end
            Qtable{1,1}(pos,:) = currentState;
            Qtable{1,2}(pos,:) = currentQtable;
            pos = pos + 1;
            if pos > N
                pos = 1;
            end
            %% visualization
            for i = 1:N
                FES = FES+1;
                if FES == 10000*0.1 || mod(FES,10000) == 0
                    [kk,ll] = min(fitness);
                    RunValue(run,k) = kk;
                    Para(k,:) = pop(ll,:);
                    k=k+1;
                    fprintf('Algorithm:%s problemIndex:%d Run:%d FES:%d Best:%g\n','SLDE_MPEDE',problem,run,FES,kk);
                end
                if TimeFlag == 0
                    if min(fitness) <= TEV
                        TempFES = FES;
                        TimeFlag = 1;
                    end
                end
            end
        end
        [kk,ll]=min(fitness);
        gbest=pop(ll,:);
        t2=clock;
        RunTime(run)=etime(t2,t1);
        RunResult(run)=kk;
        RunFES(run)=TempFES;
        RunOptimization(run,1:D)=gbest;
        RunParameter{run}=Para;
    end
end