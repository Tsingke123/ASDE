%% Differential evolution with multi-population based ensemble of mutation strategies
%by ZhenYu Wang on 2021/08/19
%problem: the serial number of testing function recorded in "Public\benchmark_func.m"
%N: the population size
%runmax: the number of the algorithm runs
%RunResult: the  optimal value produced by each algorithm runs
%RunOptimization: the optimal value produced by reach algorithm runs
%RunValue: the fitness of optimal value produced by each 10000 FES
%RunParameter:the optimal value produced by each 10000 FES
%RunTime: the time spent by each algorithm runs
%RunFES: the FES required to satisfy the conditions
function [RunResult,RunValue,RunTime,RunFES,RunOptimization,RunParameter]=MPEDE(problem,N,runmax)
    'MPEDE'
    D=Dim(problem);%13-16�е���˼�ο�CEP
    lu=Boundary(problem,D);
    tempTEV=Error(D);
    TEV = tempTEV(problem);
    FESMAX=D*10000;
    genMax = ceil(FESMAX/N);
    RunOptimization=zeros(runmax,D);
    % The total number of runs
    for run = 1 : runmax
        TimeFlag=0;
        TempFES=FESMAX;
        t1=clock;
        %% initialization
        %initializing control parameters of MPEDE
        pop_size = N;
        c = 0.1;
        lambda1 = 0.2;
        lambda2 = 0.2;
        lambda3 = 0.2;
        ng = 20;
        FES = 0;         %Function evaluations
        %population size boundary
        boundary1 = round(lambda1 * pop_size);                   
        boundary2 = round((lambda1 + lambda2) * pop_size);
        boundary3 = round((lambda1 + lambda2 + lambda3) * pop_size);
        
        %Initializing control parameters,Archive, goodF and gooCR of mutation strategy DE/current-to-pbest/1
        muCR1 = 0.5;
        muF1 = 0.5;
        p = 0.05;
        FES1 = 0;       %Function evaluations of DE/current-to-pbest/1
        deltaF1 = 0;    %Improvement of fitness value
        goodF1=[];      
        goodCR1=[];
        archive.NP = pop_size; % the maximum size of the archive
        archive.pop = zeros(0, D); % the solutions stored in te archive
        archive.funvalues = zeros(0, 1); % the function value of the archived solutions
        
        %control parameters of mutation strategy DE/current-to-rand/1
        muCR2 = 0.5;
        muF2 = 0.5;
        FES2 = 0;       %Function evaluations of DE/current-to-pbest/1
        deltaF2 = 0;    %Improvement of fitness value
        goodF2=[];      
        goodCR2=[];
        
        %control parameters of mutation strategy DE/rand/1
        muCR3 = 0.5;
        muF3 = 0.5;
        FES3 = 0;       %Function evaluations of DE/current-to-pbest/1
        deltaF3 = 0;    %Improvement of fitness value
        goodF3=[];      
        goodCR3=[];
        
        %initializing population and calculating fitness value
        pop = repmat(lu(1, :), pop_size, 1) + rand(pop_size, D) .* (repmat(lu(2, :) - lu(1, :), pop_size, 1));
        fitness = benchmark_func(pop, problem);
        FES = N;
        gen = 1;
        bestMutationIndex = ceil(rand * 3); %Randomly assigned reward population
        k = 1;  %The number of Sampling point 
        while gen <= genMax
            %Evolution
            gen = gen + 1;
            %% population partition
            randIndex = randperm(pop_size);
            if bestMutationIndex == 1
                pop1= pop(randIndex(1:boundary1),:);
                fitness1 = fitness(randIndex(1:boundary1),1);
                pop2= pop(randIndex(boundary1 + 1 : boundary2),:);
                fitness2 = fitness(randIndex(boundary1 + 1 : boundary2),1);
                pop3= pop(randIndex(boundary2 + 1 : boundary3),:);
                fitness3 = fitness(randIndex(boundary2 + 1 : boundary3),1);
                reward_pop= pop(randIndex(boundary3 + 1 : end),:);
                reward_fitness = fitness(randIndex(boundary3 + 1 : end),1);
                pop1 = [pop1;reward_pop];
                fitness1 = [fitness1;reward_fitness];
            elseif bestMutationIndex == 2
                pop1= pop(randIndex(1:boundary1),:);
                fitness1 = fitness(randIndex(1:boundary1),1);
                pop2= pop(randIndex(boundary1 + 1 : boundary2),:);
                fitness2 = fitness(randIndex(boundary1 + 1 : boundary2),1);
                pop3= pop(randIndex(boundary2 + 1 : boundary3),:);
                fitness3 = fitness(randIndex(boundary2 + 1 : boundary3),1);
                reward_pop= pop(randIndex(boundary3 + 1 : end),:);
                reward_fitness = fitness(randIndex(boundary3 + 1 : end),1);
                pop2 = [pop2;reward_pop];
                fitness2 = [fitness2;reward_fitness];
            else
                pop1= pop(randIndex(1:boundary1),:);
                fitness1 = fitness(randIndex(1:boundary1),1);
                pop2= pop(randIndex(boundary1 + 1 : boundary2),:);
                fitness2 = fitness(randIndex(boundary1 + 1 : boundary2),1);
                pop3= pop(randIndex(boundary2 + 1 : boundary3),:);
                fitness3 = fitness(randIndex(boundary2 + 1 : boundary3),1);
                reward_pop= pop(randIndex(boundary3 + 1 : end),:);
                reward_fitness = fitness(randIndex(boundary3 + 1 : end),1);
                pop3 = [pop3;reward_pop];
                fitness3 = [fitness3;reward_fitness];
            end
        %% DE/current-to-pbest/1
            pop1_size = size(pop1,1);
            preFitness1 = fitness1;
            %For generating control parameters
            if ~isempty(goodF1)
                muCR1 = (1 - c) * muCR1 + c * mean(goodCR1);
                muF1 = (1 - c) * muF1 + c * sum(goodF1 .^ 2) / sum(goodF1); % Lehmer mean
            end
            [F1, CR1] = randFCR(pop1_size, muCR1, 0.1, muF1, 0.1);
            
            r0 = [1 : pop1_size];
            popAll = [pop1; archive.pop];
            [r1, r2] = gnR1R2(pop1_size, size(popAll, 1), r0);
            % Find the p-best solutions
            [~, indBest] = sort(fitness1, 'ascend');
            pNP = max(round(p * pop1_size), 2); % choose at least two best solutions
            randindex = ceil(rand(1, pop1_size) * pNP); % select from [1, 2, 3, ..., pNP]
            randindex = max(1, randindex); % to avoid the problem that rand = 0 and thus ceil(rand) = 0
            pbest = pop1(indBest(randindex), :); % randomly choose one of the top 100p% solutions
            % == == == == = Mutation operator== == == == =
            vi = pop1 + F1(:, ones(1, D)) .* (pbest - pop1 + pop1(r1, :) - popAll(r2, :));
            vi = boundConstraint(vi, lu);
            % == == == == = Crossover operator== == == == =
            mask = rand(pop1_size, D) > CR1(:, ones(1, D)); % mask is used to indicate which elements of ui comes from the parent
            rows = (1 : pop1_size)'; cols = floor(rand(pop1_size, 1) * D)+1; % choose one position where the element of ui doesn't come from the parent
            jrand = sub2ind([pop1_size D], rows, cols); mask(jrand) = false;
            ui = vi; ui(mask) = pop1(mask);
            % == == == == = Selection operator== == == == =
            offspring_fitness = benchmark_func(ui, problem);
            [fitness1, I] = min([fitness1,offspring_fitness],[],2);
            archive = updateArchive(archive, pop1(I == 2, :), fitness1(I == 2));
            pop1(I == 2,:) = ui(I == 2,:);
            goodF1 = F1(I == 2,1);
            goodCR1 = CR1(I == 2,1);
            FES1 = FES1 + pop1_size;
            deltaF1 = deltaF1 + sum(preFitness1 - fitness1);
            
       %% DE/current-to-rand/1
            pop2_size = size(pop2,1);
            preFitness2 = fitness2;
            %For generating control parameters
            if ~isempty(goodF2)
                muCR2 = (1 - c) * muCR2 + c * mean(goodCR2);
                muF2 = (1 - c) * muF2 + c * sum(goodF2 .^ 2) / sum(goodF2); % Lehmer mean
            end
            [F2, CR2] = randFCR(pop2_size, muCR2, 0.1, muF2, 0.1);
            
            r0 = 1:pop2_size;
            [r1,r2,r3] = gnR1R2R3(pop2_size,r0);
            % == == == == = Mutation operator== == == == =
            vi = pop2 + rand(pop2_size,1) .* (pop2(r1,:) - pop2) + F2 .* (pop2(r2, :) - pop2(r3, :));
            vi = boundConstraint(vi, lu);
            ui = vi;
            % == == == == = Selection operator== == == == =
            offspring_fitness = benchmark_func(ui, problem);
            [fitness2, I] = min([fitness2,offspring_fitness],[],2);
            pop2(I == 2,:) = ui(I == 2,:);
            goodF2 = F2(I == 2,1);
            goodCR2 = CR2(I == 2,1); 
            FES2 = FES2 + pop2_size;
            deltaF2 = deltaF2 + sum(preFitness2 - fitness2);
            
    %% DE/rand/1
            pop3_size = size(pop3,1);
            preFitness3 = fitness3;
            %For generating control parameters
            if ~isempty(goodF3)
                muCR3 = (1 - c) * muCR3 + c * mean(goodCR3);
                muF3 = (1 - c) * muF3 + c * sum(goodF3 .^ 2) / sum(goodF3); % Lehmer mean
            end
            [F3, CR3] = randFCR(pop3_size, muCR3, 0.1, muF3, 0.1);
            r1 = zeros(pop3_size,1);
            r2 = zeros(pop3_size,1);
            r3 = zeros(pop3_size,1);
            for i = 1:pop3_size
                tmp = randperm(pop3_size);
                r1(i) = tmp(1);
                r2(i) = tmp(2);
                r3(i) = tmp(3);
            end
            % == == == == = Mutation operator== == == == =
            vi = pop3(r1,:) + F3 .* (pop3(r2, :) - pop3(r3, :));
            vi = boundConstraint(vi, lu);
            % == == == == = Crossover operator== == == == =
            mask = rand(pop3_size, D) > CR3(:, ones(1, D)); % mask is used to indicate which elements of ui comes from the parent
            rows = (1 : pop3_size)'; cols = floor(rand(pop3_size, 1) * D)+1; % choose one position where the element of ui doesn't come from the parent
            jrand = sub2ind([pop3_size D], rows, cols); mask(jrand) = false;
            ui = vi; ui(mask) = pop3(mask);
            % == == == == = Selection operator== == == == =
            offspring_fitness = benchmark_func(ui, problem);
            [fitness3, I] = min([fitness3,offspring_fitness],[],2);
            pop3(I == 2,:) = ui(I == 2,:);
            goodF3 = F3(I == 2,1);
            goodCR3 = CR3(I == 2,1);
            FES3 = FES3 + pop3_size;
            deltaF3 = deltaF3 + sum(preFitness3 - fitness3);
            
       %% merging population and updating rate of subpopulation
           pop = [pop1;pop2;pop3];
           fitness = [fitness1;fitness2;fitness3];
           if mod(gen,ng) == 0
               improvement1 = deltaF1 / FES1;
               improvement2 = deltaF2 / FES2;
               improvement3 = deltaF3 / FES3;
               [~,bestMutationIndex] = max([improvement1,improvement2,improvement3]);
               deltaF1 = 0; FES1 = 0;
               deltaF2 = 0; FES2 = 0;
               deltaF3 = 0; FES3 = 0;
           end
       %% visualization
           for i=1:N
               FES=FES+1;
                if FES==10000*0.1||mod(FES,10000)==0
                    [kk,ll]=min(fitness);
                    RunValue(run,k)=kk;
                    Para(k,:)=pop(ll,:);
                    k=k+1;
                    fprintf('Algorithm:%s problemIndex:%d Run:%d FES:%d Best:%g\n','MPEDE',problem,run,FES,kk);
                end
                if TimeFlag==0
                    if min(fitness)<=TEV
                        TempFES=FES;
                        TimeFlag=1;
                    end
                end
           end
        end
        [kk,ll]=min(fitness);
        gbest=pop(ll,:);
        t2=clock;
        RunTime(run)=etime(t2,t1);
        RunResult(run)=kk;
        RunFES(run)=TempFES;
        RunOptimization(run,1:D)=gbest;
        RunParameter{run}=Para;
    end
end


function [F,CR] = randFCR(NP, CRm, CRsigma, Fm,  Fsigma)

% this function generate CR according to a normal distribution with mean "CRm" and sigma "CRsigma"
%           If CR > 1, set CR = 1. If CR < 0, set CR = 0.
% this function generate F  according to a cauchy distribution with location parameter "Fm" and scale parameter "Fsigma"
%           If F > 1, set F = 1. If F <= 0, regenrate F.
%
% Version: 1.1   Date: 11/20/2007
% Written by Jingqiao Zhang (jingqiao@gmail.com)

    %% generate CR
    CR = CRm + CRsigma * randn(NP, 1);
    CR = min(1, max(0, CR));                % truncated to [0 1]

    %% generate F
    F = randCauchy(NP, 1, Fm, Fsigma);
    F = min(1, F);                          % truncation

    % we don't want F = 0. So, if F<=0, we regenerate F (instead of trucating it to 0)
    pos = find(F <= 0);
    while ~ isempty(pos)
        F(pos) = randCauchy(length(pos), 1, Fm, Fsigma);
        F = min(1, F);                      % truncation
        pos = find(F <= 0);
    end
end 

% Cauchy distribution: cauchypdf = @(x, mu, delta) 1/pi*delta./((x-mu).^2+delta^2)
function result = randCauchy(m, n, mu, delta)

% http://en.wikipedia.org/wiki/Cauchy_distribution
result = mu + delta * tan(pi * (rand(m, n) - 0.5));
end

