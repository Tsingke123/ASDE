function [RunResult,RunValue,RunTime,RunFES,RunOptimization,RunParameter]=ACODE(problem,N,runmax)
    'ACODE'
    D=Dim(problem);
    lu=Boundary(problem,D);
    tempTEV=Error(D);
    TEV = tempTEV(problem);
    FESMAX=D*10000;
    RunValue=zeros(runmax,D+1);
    RunOptimization=zeros(runmax,D);

    for run=1:runmax
        TimeFlag=0;
        TempFES=FESMAX;
        t1=clock;
        F=[1.0 1.0 0.8];
        CR=[0.1 0.9 0.2];
        x=Initpop(N,D,lu);
        fitness=benchmark_func(x,problem);
        LEP=50;
        sucMemo1=zeros(LEP,3);
        failMemo1=zeros(LEP,3);
        sucMemo2=zeros(LEP,3);
        failMemo2=zeros(LEP,3);
        sucMemo3=zeros(LEP,3);
        failMemo3=zeros(LEP,3);
        FES=N;
        k=1;
        gen=0;
        while FES<=FESMAX
            gen=gen+1;
            if gen<LEP
                paraProb=ones(3,3)*1/3;
            else
                paraSR=sum(sucMemo1)./(sum(sucMemo1)+sum(failMemo1))+0.01; %���㵱ǰ����һ�ֱ������ѡ�����������Ӧ�ĳɹ���
                paraProb(1,:)=paraSR./sum(paraSR); %���㵱ǰ����һ�ֱ������ѡ�����������Ӧ����Գɹ���
                paraSR=sum(sucMemo2)./(sum(sucMemo2)+sum(failMemo2))+0.01;
                paraProb(2,:)=paraSR./sum(paraSR);
                paraSR=sum(sucMemo3)./(sum(sucMemo3)+sum(failMemo3))+0.01;
                paraProb(3,:)=paraSR./sum(paraSR);
            end
            n=zeros(3,3);
            n_s=zeros(3,3);
            n_f=zeros(3,3);
            for i=1:N
                u=[];
                paraindex(1)=length(find(rand>cumsum(paraProb(1,:))))+1;
                paraindex(2)=length(find(rand>cumsum(paraProb(2,:))))+1;
                paraindex(3)=length(find(rand>cumsum(paraProb(3,:))))+1;
                indexSet=1:N;
                indexSet(i)=[];
                temp=floor(rand*(N-1))+1;
                index(1)=indexSet(temp);
                indexSet(temp)=[];
                temp=floor(rand*(N-2))+1;
                index(2)=indexSet(temp);
                indexSet(temp)=[];
                temp=floor(rand*(N-3))+1;
                index(3)=indexSet(temp);
                v1=x(index(1),:)+F(paraindex(1)).*(x(index(2),:)-x(index(3),:));
                jrand=floor(rand*D)+1;
                for j=1:D

                    if v1(j)>lu(2,j)
                        v1(j)=max(lu(1,j),2*lu(2,j)-v1(j));
                    end
                    if v1(j)<lu(1,j)
                        v1(j)=min(lu(2,j),2*lu(1,j)-v1(j));
                    end

                    if (rand<CR(paraindex(1)))||(j==jrand)
                        u1(j)=v1(j);
                    else
                        u1(j)=x(i,j);
                    end
                end
                n(1,paraindex(1))=n(1,paraindex(1))+1;

                index(1:3)=floor(rand(1,3)*N)+1;
                v2=x(i,:)+rand*(x(index(1),:)-x(i,:))+F(paraindex(2)).*(x(index(2),:)-x(index(3),:));

                for j=1:D
                    if v2(j)>lu(2,j)
                        v2(j)=max(lu(1,j),2*lu(2,j)-v2(j));
                    end
                    if v2(j)<lu(1,j)
                        v2(j)=min(lu(2,j),2*lu(1,j)-v2(j));
                    end
                end
                u2=v2;
                n(2,paraindex(2))=n(2,paraindex(2))+1;


                indexSet=1:N;
                indexSet(i)=[];
                temp=floor(rand*(N-1))+1;
                index(1)=indexSet(temp);
                indexSet(temp)=[];
                temp=floor(rand*(N-2))+1;
                index(2)=indexSet(temp);
                indexSet(temp)=[];
                temp=floor(rand*(N-3))+1;
                index(3)=indexSet(temp);
                indexSet(temp)=[];
                temp=floor(rand*(N-4))+1;
                index(4)=indexSet(temp);
                indexSet(temp)=[];
                temp=floor(rand*(N-5))+1;
                index(5)=indexSet(temp);
                v3=x(index(1),:)+F(paraindex(3))*(x(index(2),:)-x(index(3),:))+F(paraindex(3))*(x(index(4),:)-x(index(5),:));
                jrand=floor(rand*D)+1;
                for j=1:D

                    if v3(j)>lu(2,j)
                        v3(j)=max(lu(1,j),2*lu(2,j)-v3(j));
                    end
                    if v3(j)<lu(1,j)
                        v3(j)=min(lu(2,j),2*lu(1,j)-v3(j));
                    end

                    if (rand<CR(paraindex(3)))||(j==jrand)
                        u3(j)=v3(j);
                    else
                        u3(j)=x(i,j);
                    end
                end
                n(3,paraindex(3))=n(3,paraindex(3))+1;
                u=[u;u1];
                u=[u;u2];
                u=[u;u3];
                [fnew,ll]=min(benchmark_func(u,problem));
                if fnew<fitness(i)
                    x(i,:)=u(ll,:);
                    fitness(i)=fnew;
                    n_s(ll,paraindex(ll))=n_s(ll,paraindex(ll))+1;
                end
            end
            n_f=n-n_s;
            sucMemo1(1,:)=[];
            sucMemo1(LEP,:)=n_s(1,:);
            failMemo1(1,:)=[];
            failMemo1(LEP,:)=n_f(1,:);
            sucMemo2(1,:)=[];
            sucMemo2(LEP,:)=n_s(2,:);
            failMemo2(1,:)=[];
            failMemo2(LEP,:)=n_f(2,:);
            sucMemo3(1,:)=[];
            sucMemo3(LEP,:)=n_s(3,:);
            failMemo3(1,:)=[];
            failMemo3(LEP,:)=n_f(3,:);
            for number=1:3*N
                FES=FES+1;
                if FES==10000*0.1||mod(FES,10000)==0
                    [kk,ll]=min(fitness);
                    RunValue(run,k)=kk;
                    Para(k,:)=x(ll,:);
                    k=k+1;
                    fprintf('Algorithm:%s problemIndex:%d Run:%d FES:%d Best:%g\n','ACODE',problem,run,FES,kk);
                end
                if TimeFlag==0
                    if min(fitness)<=TEV
                        TempFES=FES;
                        TimeFlag=1;
                    end
                end
            end
        end
        [kk,ll]=min(benchmark_func(x,problem));
        gbest=x(ll,:);
        t2=clock;
        RunTime(run)=etime(t2,t1);
        RunResult(run)=kk;
        RunFES(run)=TempFES;
        RunOptimization(run,1:D)=gbest;
        RunParameter{run}=Para;
    end
end




