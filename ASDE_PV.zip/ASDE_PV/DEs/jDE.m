function [RunResult,RunValue,RunTime,RunFES,RunOptimization,RunParameter]=jDE(problem,N,runmax)
    'jDE'
    D=Dim(problem);%3-6�е���˼�ο�CEP
    lu=Boundary(problem,D);
    tempTEV=Error(D);
    TEV = tempTEV(problem);
    FESMAX=D*10000;
    RunOptimization=zeros(runmax,D);
    for run = 1:runmax
        TimeFlag = 0;
        TempFES = FESMAX;
        t1 = clock;
        tau1 = 0.1;
        tau2 = 0.1;
        F = 0.5 * ones(N, 1);
        CR = 0.9 * ones(N, 1);
        % Initialize the main population
        popold = repmat(lu(1, :), N, 1) + rand(N, D) .* (repmat(lu(2, :)-lu(1, :), N, 1));

        valParents = benchmark_func(popold, problem);

        FES = N;
        k = 1;
        while FES <= FESMAX

            pop = popold;      % the old population becomes the current population

            Fold = F;
            CRold = CR;

            IF  = rand(N, 1) < tau1;
            ICR = rand(N, 1) < tau2;

            F(IF)  = 0.1 + 0.9 * rand(sum(IF), 1);
            CR(ICR) = 0.0 + 1.0 * rand(sum(ICR), 1);

            r0 = [1:N];
            [r1, r2, r3] = gnR1R2R3(N, r0);

            %  == == == == == = Mutation == == == == == == == == =
            vi  = pop(r1, :) + F(:, ones(1, D)) .* (pop(r2, :) - pop(r3, :));

            vi = boundConstraint(vi, lu);

            % == == == == =  Crossover == == == == =

            mask = rand(N, D) > CR(:, ones(1, D));     % mask is used to indicate which elements of ui comes from the parent
            rows = (1:N)'; cols = floor(rand(N, 1) * D) + 1;  % choose one position where the element of ui doesn't come from the parent
            jrand = sub2ind([N D], rows, cols); mask(jrand) = false;
            ui = vi;  ui(mask) = pop(mask);

            valOffspring = benchmark_func(ui, problem);

            %  == == == == == = Selection == == == == == =
            % I == 1: the parent is better; I == 2: the offspring is better
            [valParents, I] = min([valParents, valOffspring], [], 2);
            popold = pop;
            popold(I == 2, :) = ui(I == 2, :);
            valParents(I == 2) = valOffspring(I == 2);
            F(I == 1) = Fold(I == 1);
            CR(I == 1) = CRold(I == 1);
             for i=1:N
                 FES=FES+1;
                if FES==10000*0.1||mod(FES,10000)==0
                    [kk,ll]=min(valParents);
                    RunValue(run,k)=kk;
                    Para(k,:)=popold(ll,:);
                    k=k+1;
                    fprintf('Algorithm:%s problemIndex:%d Run:%d FES:%d Best:%g\n','jDE',problem,run,FES,kk);
                end
                if TimeFlag==0
                    if min(valParents)<=TEV
                        TempFES=FES;
                        TimeFlag=1;
                    end
                end
            end
        end
       
        [kk,ll]=min(valParents);
        gbest=popold(ll,:);
        t2=clock;
        RunTime(run)=etime(t2,t1);
        RunResult(run)=kk;
        RunFES(run)=TempFES;
        RunOptimization(run,1:D)=gbest;
        RunParameter{run}=Para;
    end
end



function [r1,r2,r3] = gnR1R2R3(NP1, r0)
    if NP1 > 4
        NP0=length(r0);
        for i = 1:NP0
            temp = randperm(NP1);
            r1r2r3=temp(1:3);
            r1r2r3(find(r1r2r3 == r0(i))) = temp(4);
            r1(i)=r1r2r3(1);
            r2(i)=r1r2r3(2);
            r3(i)=r1r2r3(3);
        end
    end
            
end       