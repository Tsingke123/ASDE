function D=Dim(problem)
% if problem<=13
%     D=30;
% elseif problem<=14
%     D=2;
% elseif problem<=15
%     D=4;
% elseif problem<=18
%     D=2;
% elseif problem<=19
%     D=3;
% elseif problem<=20
%     D=6;
% else
%     D=4;
    D=30;
end