function t_test()  

    load("ASDE.mat"); ASDE = TestFitness;
    %% MFO
    load("MFO.mat"); data = TestFitness;
    H_Result=[];
    P_Result=[];
    for i = 1:15
        [h,p] = ttest(ASDE(i,:)',data(i,:)');
        H_Result = [H_Result;h];
        P_Result = [P_Result;p];
    end
    temp = [P_Result, H_Result];
    xlswrite("MFO-ASDE-ttest-results.xls",temp);
    %% AMFO
    load("AMFO.mat"); data = TestFitness;
    H_Result=[];
    P_Result=[];
    for i = 1:15
        [h,p] = ttest(ASDE(i,:)',data(i,:)');
        H_Result = [H_Result;h];
        P_Result = [P_Result;p];
    end
    temp = [P_Result, H_Result];
    xlswrite("AMFO-ASDE-ttest-results.xls",temp);
    %% PSO
    load("PSO.mat"); data = TestFitness;
    H_Result=[];
    P_Result=[];
    for i = 1:15
        [h,p] = ttest(ASDE(i,:)',data(i,:)');
        H_Result = [H_Result;h];
        P_Result = [P_Result;p];
    end
    temp = [P_Result, H_Result];
    xlswrite("PSO-ASDE-ttest-results.xls",temp);
    %% SLPSO
    load("SLPSO.mat"); data = TestFitness;
    H_Result=[];
    P_Result=[];
    for i = 1:15
        [h,p] = ttest(ASDE(i,:)',data(i,:)');
        H_Result = [H_Result;h];
        P_Result = [P_Result;p];
    end
    temp = [P_Result, H_Result];
    xlswrite("SLPSO-ASDE-ttest-results.xls",temp);
    %% RLDE
    load("RLDE.mat"); data = TestFitness;
    H_Result=[];
    P_Result=[];
    for i = 1:15
        [h,p] = ttest(ASDE(i,:)',data(i,:)');
        H_Result = [H_Result;h];
        P_Result = [P_Result;p];
    end
    temp = [P_Result, H_Result];
    xlswrite("RLDE-ASDE-ttest-results.xls",temp);
    %% DE
    load("DE.mat"); data = TestFitness;
    H_Result=[];
    P_Result=[];
    for i = 1:15
        [h,p] = ttest(ASDE(i,:)',data(i,:)');
        H_Result = [H_Result;h];
        P_Result = [P_Result;p];
    end
    temp = [P_Result, H_Result];
    xlswrite("DE-ASDE-ttest-results.xls",temp);
    %% EPSDE
    load("EPSDE.mat"); data = TestFitness;
    H_Result=[];
    P_Result=[];
    for i = 1:15
        [h,p] = ttest(ASDE(i,:)',data(i,:)');
        H_Result = [H_Result;h];
        P_Result = [P_Result;p];
    end
    temp = [P_Result, H_Result];
    xlswrite("EPSDE-ASDE-ttest-results.xls",temp);
end

