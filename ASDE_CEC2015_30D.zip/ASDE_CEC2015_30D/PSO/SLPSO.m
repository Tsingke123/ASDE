%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  Implementation of a social learning PSO (SL-PSO) for scalable optimization
%%
%%  See the details of SL-PSO in the following paper
%%  R. Cheng and Y. Jin, 1,
%%  Information Sicences, 2014
%%
%%  The source code SL-PSO is implemented by Ran Cheng 
%%
%%  If you have any questions about the code, please contact: 
%%  Ran Cheng at r.cheng@surrey.ac.uk 
%%  Prof. Yaochu Jin at yaochu.jin@surrey.ac.uk
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function [RunResult,RunBest,RunTime,RunFES] = SLPSO(opt,ObjFun) 
function [RunResult,RunValue,RunTime,RunFES,RunOptimization,RunParameter]=SLPSO(ObjFun,N,runmax)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global initial_flag

DimSize=Dim(ObjFun);%3-6�е���˼�ο�CEP
lu=Boundary(ObjFun,DimSize);
VTR=Error(DimSize);
runmax = runmax;
maxFES=DimSize*10000;
genmax = floor(maxFES/N);
RunOptimization=zeros(runmax,DimSize);

%d: dimensionality
d = DimSize;
%maxfe: maximal number of fitness evaluations
maxfe = maxFES;
funcid=ObjFun;
% lu=[xmin;xmax];

% several runs
for run = 1 : runmax
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
    initial_flag = 0; TimeFlag = 0; TempTime = inf; TempFES = inf; t1 = clock;  k = 1;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %parameter initiliaztion
    M = 100 - floor(d/10);
    m = 100;
    c3 = d/M*0.01;
    PL = zeros(m,1);

    for i = 1 : m
        PL(i) = (1 - (i - 1)/m)^log(sqrt(ceil(d/M)));
    end

    % initialization
    XRRmin = repmat(lu(1, :), m, 1);
    XRRmax = repmat(lu(2, :), m, 1);
    rand('seed', sum(100 * clock));
    p = XRRmin + (XRRmax - XRRmin) .* rand(m, d);
    fitness = benchmark_func(p, funcid); 
    v = zeros(m,d);
    bestever = 1e200;
    
    FES = m;
    gen = 0;
    ploti = 1;    

    % main loop
    while(FES < maxfe)

        % population sorting
        [fitness,rank] = sort(fitness, 'descend');
        p = p(rank,:);
        v = v(rank,:);
        besty = fitness(m);
        %bestp = p(m, :);
        bestever = min(besty, bestever);
        
        % center position
        center = ones(m,1)*mean(p);
        
        %random matrix 
        %rand('seed', sum(100 * clock));
        randco1 = rand(m, d);
        %rand('seed', sum(100 * clock));
        randco2 = rand(m, d);
        %rand('seed', sum(100 * clock));
        randco3 = rand(m, d);
        winidxmask = repmat([1:m]', [1 d]);
        winidx = winidxmask + ceil(rand(m, d).*(m - winidxmask));
        pwin = p;
        for j = 1:d
                pwin(:,j) = p(winidx(:,j),j);
        end
        
        % social learning
         lpmask = repmat(rand(m,1) < PL, [1 d]);
         lpmask(m,:) = 0;
         v1 =  1*(randco1.*v + randco2.*(pwin - p) + c3*randco3.*(center - p));
         p1 =  p + v1;   
         
         
         v = lpmask.*v1 + (~lpmask).*v;         
         p = lpmask.*p1 + (~lpmask).*p;
         
         % boundary control
        for i = 1:m - 1
            p(i,:) = max(p(i,:), lu(1,:));
            p(i,:) = min(p(i,:), lu(2,:));
        end
        
        
        % fitness evaluation
        fitness(1:m - 1,:) = benchmark_func(p(1:m - 1,:), funcid);   
%         FES = FES + m - 1;
        gen = gen + 1;
        
        gBestFit=bestever;
%         RunBest(run,gen) = gBestFit;   
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Output
            for i = 1:m-1
                FES = FES + 1;
                if FES==10000*0.1||mod(FES,10000)==0
                    [kk,ll]=min(fitness);
                    RunValue(run,k)=kk;
                    Para(k,:)=p(ll,:);
                    k=k+1;
                    fprintf('EA-2:%s ObjFun:%d PopSize:%d Run:%d Gen:%d FES:%d Best:%g\n','SLPSO',ObjFun,m,run,gen,FES,gBestFit);
                end
            end
            % Store the accepted running time
            if TimeFlag == 0
                if gBestFit <= VTR
                    t2 = clock; t = etime(t2,t1); TempTime = t; TempFES = FES;  TimeFlag = 1;
                end
            end
                       
           if FES >= maxFES
               break;
           end
           
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [kk,ll]=min(fitness);
    gbest = p(ll,:);
    t3 = clock; t = etime(t3,t1); 
    RunTime(run,1) = min(TempTime,t);  RunTime(run,2) = t;  RunFES(run) = min(TempFES,FES);  RunResult(run) = gBestFit;
    RunParameter=Para;
    RunOptimization(run,1:DimSize)=gbest;
end



