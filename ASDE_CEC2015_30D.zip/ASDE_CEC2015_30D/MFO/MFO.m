function [RunResult,RunValue,RunTime,RunFES,RunOptimization,RunParameter]=MFO(problem,N,runmax)
'MFO'
D=Dim(problem);%3-6�е���˼�ο�CEP
lu=Boundary(problem,D);
TEV=Error(D);
FESMAX=10000*D;
RunOptimization=zeros(runmax,D);

for run=1:runmax
    TimeFlag=0;
    TempFES=FESMAX;
    t1=clock;
    x=Initpop(N,D,lu);%��Ⱥ��ʼ��
    
    fitness=benchmark_func(x,problem);%����ÿһ������ĺ���ֵ  
    % Sort the first population of moths
    [fitness_sorted, I]=sort(fitness);
    sorted_population=x(I,:);
    % Update the flames
    best_flames=sorted_population;
    best_flame_fitness=fitness_sorted;
    
    FES=N;%��ǰ�ĺ������۴������������Ѽ���Ĵ���
    k=1;
    Iteration=1;               %Current iteration
    Max_iteration=FESMAX/N ;    % Maximum numbef of iterations
    
    while FES<FESMAX
        
        Flame_no=round(N-Iteration*((N-1)/Max_iteration));   %  Number of flames Eq. (3.14) in the paper
        
         % a linearly dicreases from -1 to -2 to calculate t in Eq. (3.12)
         a=-1+Iteration*((-1)/Max_iteration);
        
        %Main process of Flame's mutation    
        for i=1:N
             
            for j=1:D
                
               if i<=Flame_no % Update the position of the moth with respect to its corresponsing flame
                
                  % D in Eq. (3.13)
                  distance_to_flame=abs(sorted_population(i,j)-x(i,j));
                  b=1;
                  t=(a-1)*rand+1;                
                  % Eq. (3.12)                  
                  x(i,j)=distance_to_flame*exp(b.*t).*cos(t.*2*pi)+sorted_population(i,j);
                 
               end
            
               if i>Flame_no                  
                 % Upaate the position of the moth with respct to one flame                
                 % Eq. (3.13)
                 distance_to_flame=abs(sorted_population(Flame_no,j)-x(i,j));
                 b=1;
                 t=(a-1)*rand+1;                
                  % Eq. (3.12)                  
                  x(i,j)=distance_to_flame*exp(b.*t).*cos(t.*2*pi)+sorted_population(Flame_no,j);
                  
               end
            end
        end
        x = boundConstraint(x,lu);
        fitness = benchmark_func(x,problem);%����ÿһ������ĺ���ֵ
         % Sort the moths, choose
        double_population=[x;best_flames];
        double_fitness=[fitness;best_flame_fitness];
        [double_fitness_sorted, I]=sort(double_fitness);
        double_sorted_population=double_population(I,:);
        fitness_sorted=double_fitness_sorted(1:N);
        sorted_population=double_sorted_population(1:N,:);
        % Update the flames
        best_flames=sorted_population;
        best_flame_fitness=fitness_sorted;
        
        for i=1:N 
            if FES==10000*0.1||mod(FES,10000)==0
%                 [kk,ll]=min(fitness);
                RunValue(run,k)=best_flame_fitness(1,1);
                Para(k,:)=best_flames(1,:);
                k=k+1;
                fprintf('Algorithm:%s problemIndex:%d Run:%d FES:%d Best:%g\n','MFO',problem,run,FES,best_flame_fitness(1,1)); 
            end
            FES=FES+1;
            if TimeFlag==0
                if best_flame_fitness<=TEV %��С�ڵ��ڸ�������ֵʱ���������۵Ĵ���%
                    TempFES=FES;
                    TimeFlag=1;
                end
            end
        end
        
        Iteration=Iteration+1; 
        
    end
    t2=clock;
    RunTime(run)=etime(t2,t1);
    RunResult(run)=best_flame_fitness(1,1);
    RunFES(run)=TempFES;
    RunOptimization(run,1:D)=best_flames(1,:);
    RunParameter=Para;  
end
