%% The original Different Evolution
%problem: the serial number of testing function recorded in "Public\benchmark_func.m"
%N: the population size
%runmax: the number of the algorithm runs
%RunResult: the  optimal value produced by each algorithm runs
%RunOptimization: the optimal value produced by reach algorithm runs
%RunValue: the fitness of optimal value produced by each 10000 FES
%RunParameter:the optimal value produced by each 10000 FES
%RunTime: the time spent by each algorithm runs
%RunFES: the FES required to satisfy the conditions
function [RunResult,RunValue,RunTime,RunFES,RunOptimization,RunParameter]=DE(problem,N,runmax)
    'DE'
    D=Dim(problem);%13-16�е���˼�ο�CEP
    lu=Boundary(problem,D);
    tempTEV=Error(D);
    TEV = tempTEV(problem);
    FESMAX=D*10000;
    RunOptimization=zeros(runmax,D);
    for run=1:runmax
        TimeFlag=0;
        TempFES=FESMAX;
        t1=clock;
        CR=0.9;%�������
        F=0.5;%���첽��������߶ȣ�
        pop=Initpop(N,D,lu);%��Ⱥ��ʼ�����ο�CEP
        fitness=benchmark_func(pop,problem);%����ÿһ������ĺ���ֵ���ο�CEP
        FES=N;%��ǰ�ĺ������۴������������Ѽ���Ĵ���
        k=1;
        while FES<=FESMAX
            r1 = zeros(N,1);
            r2 = zeros(N,1);
            r3 = zeros(N,1);
            for i = 1:N
                temp = randperm(N);
                temp(temp == i) = [];
                r1(i) = temp(1);
                r2(i) = temp(2);
                r3(i) = temp(3);
            end
            %mutation operator
            v = pop(r1,:) + F.* (pop(r2,:) - pop(r3,:));
            mask = rand(N, D) < CR;
            mask(:, ceil(rand(N,1)*D)) = true; % last one dimension data performs crossover operator
            u = pop;
            u(mask) = v(mask);
            newFitness = benchmark_func(u,problem);
            mask = newFitness <= fitness;
            pop(mask,:) = u(mask,:);
            fitness(mask,:) = newFitness(mask,:);
            %% visualization
            for i = 1:N
                FES = FES+1;
                if FES == 10000*0.1 || mod(FES,10000) == 0
                    [kk,ll] = min(fitness);
                    RunValue(run,k) = kk;
                    Para(k,:) = pop(ll,:);
                    k=k+1;
                    fprintf('Algorithm:%s problemIndex:%d Run:%d FES:%d Best:%g\n','DE',problem,run,FES,kk);
                end
                if TimeFlag == 0
                    if min(fitness) <= TEV
                        TempFES = FES;
                        TimeFlag = 1;
                    end
                end
            end
        end
        [kk,ll]=min(fitness);
        gbest=pop(ll,:);
        t2=clock;
        RunTime(run)=etime(t2,t1);
        RunResult(run)=kk;
        RunFES(run)=TempFES;
        RunOptimization(run,1:D)=gbest;
        RunParameter{run}=Para;
    end
end