%% Ensemble of mutation strategies and parameters in differential evolution
%written by ZhenYu Wang on 2021/08/22
%problem: the serial number of testing function recorded in "CEC*\benchmark_func.m"
%N: the population size
%runmax: the number of the algorithm runs
%RunResult: the  optimal value produced by each algorithm runs
%RunOptimization: the optimal value produced by reach algorithm runs
%RunValue: the fitness of optimal value produced by each 10000 FES
%RunParameter:the optimal value produced by each 10000 FES
%RunTime: the time spent by each algorithm runs
%RunFES: the FES required to satisfy the conditions
function [RunResult,RunValue,RunTime,RunFES,RunOptimization,RunParameter]=EPSDE(problem,N,runmax)
    'EPSDE'
    D=Dim(problem);%13-16�е���˼�ο�CEP
    lu=Boundary(problem,D);
    tempTEV=Error(D);
    TEV = tempTEV(problem);
    FESMAX=D*10000;
    RunOptimization=zeros(runmax,D);
    pop_size = N;
    
    Fm = [0.4; 0.5; 0.6; 0.7; 0.8; 0.9];
    CRm = [0.1; 0.2; 0.3; 0.4; 0.5; 0.6; 0.7; 0.8; 0.9];
    
    for run = 1 : runmax
        TimeFlag = 0;
        TempFES = FESMAX;
        t1 = clock;
        
        %% Initialize the main population
        pop = repmat(lu(1, :), pop_size, 1) + rand(pop_size, D) .* (repmat(lu(2, :) - lu(1, :), pop_size, 1));
        fitness = benchmark_func(pop, problem);
        FES = pop_size;
        %Randomly allocate the parameters and strategy
        PS = zeros(pop_size,3);         %PS=(strategy,F,CR)
        PS(:,1) = randi(3,pop_size,1);
        PS(:,2) = Fm(randi(size(Fm,1),pop_size,1));
        PS(:,3) = CRm(randi(size(CRm,1),pop_size,1));
        
        k = 1;      %the sample counter 
        while FES < FESMAX
            [~,bestIndex] = min(fitness);
            offspring = zeros(pop_size,D);
            offspring_fitness = zeros(pop_size,1);
            for i = 1:pop_size
                mask = rand(1,D) < PS(i,3);
                if sum(mask) == 0
                    mask(randi(D)) = true;
                end
                %DE/best/2/bin
                if PS(i,1) == 1
                    tmp = randperm(pop_size);
                    r1 = tmp(1);
                    r2 = tmp(2);
                    r3 = tmp(3);
                    r4 = tmp(4);
                    vi = pop(bestIndex,:) + PS(i,2) .* (pop(r1,:) - pop(r2,:) + pop(r3,:) - pop(r4,:));
                    offspring(i,:) = pop(i,:);
                    offspring(i,mask) = vi(mask);
                end
                %DE/rand/1/bin
                if PS(i,1) == 2
                    tmp = randperm(pop_size);
                    r1 = tmp(1);
                    r2 = tmp(2);
                    r3 = tmp(3);
                    vi = pop(r1,:) + PS(i,2) .* (pop(r2,:) - pop(r3,:));
                    offspring(i,:) = pop(i,:);
                    offspring(i,mask) = vi(mask);
                end
                %DE/current-to-rand/1
                if PS(i,1) == 3
                    tmp = randperm(pop_size);
                    tmp(tmp == i) = [];
                    r1 = tmp(1);
                    r2 = tmp(2);
                    r3 = tmp(3);
                    offspring(i,:) = pop(i,:) + rand(1,D) .* (pop(r1,:) - pop(i,:)) + PS(i,2) .* (pop(r2,:) - pop(r3,:));
                end
            end
            offspring_fitness = benchmark_func(offspring,problem);
            %Selection
            mask = offspring_fitness < fitness;
            pop(mask,:) = offspring(mask,:);
            fitness(mask,1) = offspring_fitness(mask,1);
            
            %Update PS, and randomly selection conbination from pools or 
            %from the successful combination stored with equal probability
            tmpPS = PS(mask,:);     %successful combination on current population
            successNum = sum(mask);
            for i = 1:pop_size
                if mask(i,1) == 0
                    if rand < 0.5 && ~isempty(tmpPS)
                        PS(i,:) = tmpPS(randi(successNum),:);
                    else
                        PS(i,1) = randi(3);
                        PS(i,2) = Fm(randi(size(Fm,1)));
                        PS(i,3) = CRm(randi(size(CRm,1)));
                    end
                end
            end
            %% visualization
            for i = 1:N
                FES = FES+1;
                if FES == 10000*0.1 || mod(FES,10000) == 0
                    [kk,ll] = min(fitness);
                    RunValue(run,k) = kk;
                    tempPara(k,:) = pop(ll,:);
                    k=k+1;
                    fprintf('Algorithm:%s problemIndex:%d Run:%d FES:%d Best:%g\n','EPSDE',problem,run,FES,kk);
                end
                if TimeFlag == 0
                    if min(fitness) <= TEV
                        TempFES = FES;
                        TimeFlag = 1;
                    end
                end
            end
            
        end
        [kk,ll] = min(fitness);
        gbest = pop(ll,:);
        t2 = clock;
        RunTime(run) = etime(t2,t1);
        RunResult(run) = kk;
        RunFES(run) = TempFES;
        RunOptimization(run,1:D) = gbest;
        RunParameter{run} = tempPara;
    end
end
