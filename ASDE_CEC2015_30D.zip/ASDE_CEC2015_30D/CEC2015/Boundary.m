function lu=Boundary(problem,D)
        lu=[-100*ones(1,D);100*ones(1,D)];
end